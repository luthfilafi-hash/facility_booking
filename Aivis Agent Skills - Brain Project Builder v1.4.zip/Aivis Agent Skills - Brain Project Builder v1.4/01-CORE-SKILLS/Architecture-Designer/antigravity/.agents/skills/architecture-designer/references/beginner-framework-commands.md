# Beginner Framework Commands

Use this file when the user is new to Laravel, CakePHP, Artisan, Bake, Composer, migrations, or local PHP framework setup.

## First Explain

Before commands, tell the user what the command does, where to run it, what success looks like, and what the next check is.

## Laravel Safe Checks

```bash
composer show laravel/framework
php artisan --version
php artisan list
php artisan migrate:status
php artisan route:list
```

## Laravel Common Generation

```bash
php artisan make:model Product -m
php artisan make:controller ProductController --resource --model=Product
php artisan make:request StoreProductRequest
php artisan migrate
php artisan route:list
```

After generation, inspect migrations, model relationships, controllers, form requests, routes, Blade forms, `@csrf`, middleware, policies/roles, validation errors, logs, and browser CRUD flow.

## CakePHP Safe Checks

On macOS/Linux:

```bash
composer show cakephp/cakephp
composer show cakephp/bake
composer show cakephp/migrations
bin/cake
bin/cake routes
bin/cake migrations status
```

On Windows, use `bin\cake` instead of `bin/cake`.

## CakePHP Common Generation

```bash
bin/cake bake migration CreateProducts name:string description:text created modified
bin/cake migrations migrate
bin/cake bake model Products
bin/cake bake controller Products
bin/cake bake template Products
bin/cake bake all Products
bin/cake routes
```

After Bake, inspect Table associations, validation, buildRules, Entity accessible fields, controller actions, templates, FormHelper fields, CSRF, escaping, auth/role checks, validation errors, logs, and browser CRUD flow.

## Never Run Without Confirmation

Do not run database reset/drop commands, destructive migrations, production deployment commands, secret changes, forced overwrites, or bulk deletes without backup and explicit approval.
