# Official Client Use Agreement

Product: **Aivis Agent Skills - Brain Project Builder**

Version: **1.4**

This agreement is a plain-language usage letter for selling or sharing the Aivis Agent Skills - Brain Project Builder. It is not legal advice. The seller should review and adjust it before commercial use, especially if local laws or business requirements apply.

## 1. Parties

Seller / Bundle Owner:

```text
Name / Business:
Email / Contact:
Address / Location:
```

Buyer:

```text
Name / Business:
Email / Contact:
Address / Location:
```

Purchase / Transfer Details:

```text
Purchase date:
Amount paid:
Payment method:
Version received: Aivis Agent Skills - Brain Project Builder v1.4
```

## 2. What The Buyer Receives

The buyer receives one copy of the Aivis Agent Skills - Brain Project Builder v1.4, which may include:

- System Website Project Builder core skill.
- Architecture Designer Kit.
- UI Component Builder Kit.
- QA Security Auditor Kit.
- Deployment Admin Kit.
- Adapter formats for Codex, Claude Code, Cursor, Antigravity, ChatGPT/project instructions, and generic `AGENTS.md` usage.
- Quick-start prompts, install notes, compatibility notes, checklists, and example prompts where included.

The bundle is an AI instruction and workflow product. It is not a finished website, not a guarantee of perfect code, and not a replacement for testing, security review, or developer judgment.

## 3. Allowed Use

The buyer may:

- Use the bundle for their own website projects.
- Use the bundle for client website projects they personally work on.
- Copy the needed adapter into a client project when required for that client project.
- Modify the instructions for their own or client project workflow.
- Use the bundle with supported AI tools listed in the included compatibility guide.

## 4. Not Allowed

The buyer may not:

- Resell the bundle or any included kit.
- Redistribute the bundle or any included kit for free or for payment.
- Repackage the bundle as their own product.
- Upload the bundle to marketplaces, template stores, prompt libraries, public repositories, file-sharing sites, or community downloads.
- Sublicense, rent, lease, lend, or transfer the bundle to another person or company.
- Claim authorship or ownership of the original bundle.
- Remove or hide the license terms when sharing a project-specific adapter with a client team.

## 5. Client Project Boundary

The buyer may use this bundle while building client projects, but the buyer's client does not receive resale or redistribution rights to the bundle.

If a client project needs an instruction file inside the project repository, the buyer may include only the project-specific adapter needed for that project. The buyer should not give the client the full product package unless that client separately purchases the bundle or receives written permission from the seller.

## 6. Buyer Responsibilities

The buyer understands that AI-assisted work must be reviewed and tested.

The buyer is responsible for checking generated code, testing website functionality, reviewing database changes, reviewing security-sensitive features, confirming deployment behavior, and protecting credentials, passwords, API keys, and private data.

## 7. No Warranty

The bundle is provided as-is.

The seller does not guarantee perfect code, secure code, bug-free websites, successful deployment, compatibility with every AI tool, or that an AI agent will always follow every instruction perfectly.

## 8. Support Boundary

Included support, if any:

```text
Support included:
Support period:
Support channel:
```

Support does not include custom website development, fixing the buyer's full project, debugging hosting accounts, writing custom business logic, or providing unlimited revisions unless separately agreed in writing.

## 9. Buyer Acknowledgement

By signing below, the buyer confirms that they understand what the bundle is, understand the allowed use, agree not to resell or redistribute it, and accept responsibility for reviewing and testing all AI-assisted work.

## 10. Signatures

Seller / Bundle Owner:

```text
Name:
Signature:
Date:
```

Buyer:

```text
Name:
Signature:
Date:
```

Witness, optional:

```text
Name:
Signature:
Date:
```

## 11. Notes

```text
Additional terms or notes:
```
