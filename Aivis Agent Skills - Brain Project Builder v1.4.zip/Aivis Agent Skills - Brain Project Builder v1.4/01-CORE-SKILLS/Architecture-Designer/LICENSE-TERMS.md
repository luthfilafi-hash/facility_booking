# License Terms

Version: `1.4`

These are plain-language product terms for the Aivis Agent Skills - Brain Project Builder v1.4. They are not legal advice. Use `OFFICIAL-CLIENT-USE-AGREEMENT.md` as the signable buyer letter, and consider having it reviewed before wider commercial selling.

## Allowed Use

The buyer may:

- Use the bundle for their own website projects.
- Use the bundle for client projects they personally work on.
- Modify instructions for their own or client project workflow.
- Copy the needed adapter into a client project when required for that client project.
- Use the bundle with supported AI tools such as Codex, Claude Code, Cursor, Antigravity, ChatGPT/project instructions, and generic project-instruction compatible AI tools.

## Not Allowed

The buyer may not:

- Resell the bundle or any included kit.
- Redistribute the bundle or any included kit for free or for payment.
- Repackage the bundle as their own product.
- Upload the bundle to marketplaces, template stores, public repositories, file-sharing sites, or prompt libraries.
- Sublicense, rent, lease, lend, or transfer the bundle to another person or company.
- Claim authorship or ownership of the original bundle.
- Remove or hide these terms when sharing project-specific adapters with a client team.

## No Warranty

The bundle improves AI agent consistency, but it does not guarantee perfect code, secure code, bug-free websites, successful deployment, or compatibility with every project.

The buyer is responsible for reviewing, testing, securing, and validating all AI-assisted work.
