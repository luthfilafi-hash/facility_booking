# Version

Current version: `1.4`

## What Version 1.4 Means

This kit is packaged with `Aivis Agent Skills - Brain Project Builder v1.4` and keeps its the adaptive beginner-safe behavior while aligning with the new bundle release.

Main functional framework changes are added to the System Website Project Builder core skill. This kit remains focused on its original role and can support framework projects when selected as a supporting kit.

## Recommended Release Label

```text
Architecture Designer Kit v1.4
```

<!-- AIVIS_V14_ALL_SKILLS_VERSION_PATCH -->
## v1.4 All-Skills Framework Completion Patch

Patch label: `v1.4 All-Skills Framework Completion Patch`.

This patch adds Laravel/CakePHP role awareness across every kit and every AI adapter, including Antigravity native skill packaging where applicable.
