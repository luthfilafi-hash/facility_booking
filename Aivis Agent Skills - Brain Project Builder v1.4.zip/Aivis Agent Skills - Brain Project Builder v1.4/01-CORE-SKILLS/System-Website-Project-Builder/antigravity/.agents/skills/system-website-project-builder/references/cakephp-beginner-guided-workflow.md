# CakePHP Beginner Guided Workflow

Use this reference when the user is new to CakePHP, asks for CakePHP, CakePHP Bake, `bin/cake`, CakePHP CRUD, or wants the AI to guide them step by step.

## Core Rule

Do not only give commands. Teach the user what each step does, what command to run, what successful output should roughly mean, and what to check next.

CakePHP Bake creates a starting CRUD scaffold. It is not the finished system. After Bake, Aivis must audit, connect, secure, style, and test the generated application.

## Beginner Explanation Rule

When guiding a beginner, explain these terms briefly before using them:

- CakePHP: the PHP framework used for the project.
- Composer: the PHP dependency manager used to install CakePHP packages.
- `bin/cake`: CakePHP's command-line tool. On Windows, use `bin\cake`.
- Migration: a version-controlled database change.
- Bake: CakePHP's generator for model/table/entity, controller, templates, tests, and CRUD files.
- Table class: the CakePHP ORM class that controls validation, associations, and database rules.
- Entity class: the object that represents one database row.
- Controller: receives the web request and decides what data/view to use.
- Template: the page shown to the user.

## The Correct Beginner-Safe Sequence

### 1. Identify Project State

Decide whether this is:

- a brand-new CakePHP app,
- an existing CakePHP app,
- a plain PHP project being converted to CakePHP,
- or a Laravel/plain PHP project accidentally mixed with CakePHP instructions.

If there is a framework mismatch, stop before generating files.

### 2. Check Environment And CakePHP Tools

Guide the user to open the project terminal and run:

```bash
php -v
composer -V
composer show cakephp/cakephp
composer show cakephp/bake
composer show cakephp/migrations
bin/cake
```

Windows note:

```bat
bin\cake
```

If Bake is missing:

```bash
composer require --dev cakephp/bake
```

If Migrations is missing:

```bash
composer require cakephp/migrations "@stable"
bin/cake plugin load Migrations
```

### 3. Confirm Database And ERD Before Bake

Before running `bake all`, verify the ERD and database shape.

Check each table:

- table name uses plural snake_case, for example `products`, `order_items`, `users`;
- primary key is usually `id`;
- foreign keys end with `_id`, for example `user_id`, `product_id`;
- many-to-many relationships use a junction table, for example `products_tags`;
- required fields are `NOT NULL` where needed;
- optional fields allow null only when correct;
- `created` and `modified` timestamps are present when CakePHP convention is desired;
- indexes exist for foreign keys, search fields, and unique fields such as email;
- delete/update behavior is understood before adding foreign key constraints;
- statuses/roles are clearly defined, for example `pending`, `approved`, `rejected`.

Aivis must say whether the ERD is:

```text
ERD status: confirmed / needs correction / proposed only
Database status: migrated / imported / not created yet
Bake status: ready / not ready
```

### 4. Create Or Apply Tables

For a new app, prefer migrations:

```bash
bin/cake bake migration CreateProducts
bin/cake migrations migrate
bin/cake migrations status
```

For an existing SQL/phpMyAdmin database, import the SQL first, then confirm CakePHP can connect to it.

Check connection using:

```bash
bin/cake migrations status
```

### 5. Bake One Simple Table First

For beginners, do not instantly bake every table unless the database and environment are already confirmed. Bake one safe table first to validate setup:

```bash
bin/cake bake all Products
```

Then check:

- did CakePHP create `ProductsTable.php`?
- did it create `Product.php` entity?
- did it create `ProductsController.php`?
- did it create templates under `templates/Products/`?
- can the browser open `/products`?

If this fails, fix the environment/schema before baking the rest.

### 6. Bake All Approved Tables

After the pilot bake passes, bake each approved table:

```bash
bin/cake bake all Users
bin/cake bake all Products
bin/cake bake all Orders
bin/cake bake all OrderItems
```

Use table names from the actual database. Do not invent table names.

For many tables, the AI should list the planned bake order first, grouped by dependency:

1. parent tables, for example `Users`, `Categories`;
2. main tables, for example `Products`, `Orders`;
3. child/detail tables, for example `OrderItems`;
4. junction tables only when CakePHP should expose them as manage pages.

### 7. Audit Generated Files After Bake

After Bake, inspect and fix:

- `src/Model/Table/*Table.php`
  - associations: `belongsTo`, `hasMany`, `belongsToMany`;
  - validation rules;
  - `buildRules()` foreign key and unique checks.
- `src/Model/Entity/*.php`
  - `$_accessible` fields;
  - hidden sensitive fields such as password.
- `src/Controller/*Controller.php`
  - pagination;
  - redirects;
  - flash messages;
  - authorization/role checks;
  - ownership checks.
- `templates/*`
  - form fields;
  - labels;
  - empty states;
  - escaped output;
  - navigation links;
  - UI consistency.
- `config/routes.php`
  - confirm URLs work as expected.

### 8. Add Auth, Roles, And Business Logic

Bake does not know the real rules of the system. Add:

- login/logout/register flow;
- password hashing;
- role-based access, for example admin/user/vendor;
- ownership checks, for example users can only edit their own records;
- workflow status rules, for example pending to approved;
- stock/order/payment/upload logic where relevant;
- redirect rules after saving or deleting.

### 9. Complete UI And User Experience

Generated templates are basic. Improve:

- layout consistency;
- menu/navigation;
- form wording;
- validation messages;
- table readability;
- mobile responsiveness;
- empty and error states;
- dashboard links if the project has roles.

### 10. Security Pass

Before saying the app is done, check:

- CSRF/form protection is active;
- dynamic output is escaped;
- passwords are never shown;
- uploads are validated if uploads exist;
- direct URL access is blocked for protected pages;
- destructive actions use confirmation and correct HTTP method;
- sensitive config/secrets are not committed.

### 11. Browser Test Pass

Test the main workflows:

```text
Create record: pass / fail / not tested
Read/list/detail record: pass / fail / not tested
Update record: pass / fail / not tested
Delete/archive record: pass / fail / not tested
Validation error path: pass / fail / not tested
Login/logout: pass / fail / not applicable
Role restriction: pass / fail / not applicable
Navigation links: pass / fail / not tested
```

Only say `pass` when actually tested.

### 12. Final Report

The AI must report:

```text
CakePHP version:
Bake available: yes/no
Migrations available: yes/no
ERD status:
Tables baked:
Generated files audited:
Business logic added:
Auth/role checks:
Browser tests completed:
Manual checks still needed:
```

## What Comes After `bake all`?

After `bake all`, the next step is **not deployment**. The next step is this completion loop:

```text
Bake all approved tables
→ inspect generated Table/Entity/Controller/Templates
→ fix associations and validation
→ add auth and role rules
→ add real business logic
→ improve UI/templates
→ check routes
→ test CRUD in browser
→ fix errors
→ run final security and verification pass
→ only then prepare deployment or handoff
```

## Antigravity-Specific Guidance

Inside Antigravity, the agent should not overwhelm a beginner with every command at once. It should work in checkpoints:

1. show current phase and why it matters;
2. show the exact command or file change;
3. explain what output/result means;
4. inspect the result;
5. move to the next phase.

Before terminal commands that generate, migrate, overwrite, delete, seed, or deploy, show:

```text
Command plan:
Why this command is needed:
Affected files/tables:
Risk level:
Rollback or backup step:
Proceeding or waiting for confirmation:
```

For low-risk read-only commands such as version checks, the agent may proceed if tool access is available.
