## Aivis v1.4 All-Skills Framework Completion Loop

Use this loop whenever the project requests or detects Laravel, Laravel Artisan, CakePHP, CakePHP Bake, or any framework-generated website workflow.

The agent must not stop at `php artisan make:*` or `bin/cake bake *`. Generated files are only the scaffold. Aivis must guide the beginner, confirm the database/ERD, generate safely, then complete, secure, style, test, and hand off the work.

### Beginner Guidance Rule

When the user is new to Laravel or CakePHP, explain the current step in simple words before giving commands. For each command, state:

- what the command does;
- where to run it;
- what success roughly looks like;
- what to check next;
- what not to run without backup or confirmation.

### Full Framework Flow

1. **Identify the framework**
   - Laravel signs: `artisan`, `laravel/framework`, `routes/web.php`, `app/Models`, `app/Http/Controllers`, `database/migrations`, Blade views.
   - CakePHP signs: `bin/cake`, `cakephp/cakephp`, `src/Controller`, `src/Model/Table`, `src/Model/Entity`, `templates`, `config/routes.php`, `webroot`.

2. **Check local setup**
   - PHP version, Composer install, framework version, database config, local server target, and command availability.
   - If the AI cannot run commands, give the user safe commands to copy and ask them to paste the output.

3. **Check the ERD/database first**
   - Confirm tables, primary keys, foreign keys, nullable fields, unique fields, statuses, role fields, timestamps, indexes, and relationships.
   - Do not bake/generate from a weak ERD. Fix the ERD or migration plan first.

4. **Create/apply schema safely**
   - Laravel: prefer migrations and `php artisan migrate`.
   - CakePHP: prefer migrations or confirmed SQL import, then `bin/cake migrations migrate` where migrations are used.
   - Do not reset/drop/overwrite real data without explicit confirmation and backup.

5. **Pilot generation first**
   - Generate one simple table/resource first.
   - Inspect the generated output before generating all files.
   - Only continue if naming, routes, templates/views, model/entity/table class, validation, and database connection are correct.

6. **Generate approved files**
   - Laravel: use Artisan for models, migrations, controllers, requests, policies, factories, seeders, and resources when appropriate.
   - CakePHP: use Bake for model/table/entity, controller, templates, tests, and `bake all` after the database tables exist.

7. **Post-generation audit**
   - Inspect relationships/associations, validation, mass assignment, authorization, routes, controllers, templates/views, redirects, empty states, and error handling.
   - For Laravel, check `$fillable`/`$guarded`, form requests, middleware, policies, route model binding, Blade `@csrf`, storage, and Eloquent relationships.
   - For CakePHP, check `initialize()`, `validationDefault()`, `buildRules()`, entity `$_accessible`, controller actions, templates, FormHelper usage, CSRF, escaping, and associations.

8. **Complete business logic**
   - Add role checks, ownership checks, status transitions, upload rules, transactions, totals, stock/order logic, notifications, or admin rules as required by the project.

9. **Complete UI and usability**
   - Laravel: finish Blade layouts, partials/components, forms, validation messages, empty states, and navigation.
   - CakePHP: finish templates/layouts/elements, baked CRUD pages, FormHelper fields, Flash messages, empty states, and navigation.

10. **Verify with framework checks**
   - Laravel checks: `php artisan migrate:status`, `php artisan route:list`, relevant tests, browser CRUD flow, auth/role checks, validation errors, logs.
   - CakePHP checks: `bin/cake migrations status`, `bin/cake routes`, `bin/cake server` or local server, browser CRUD flow, auth/role checks, validation errors, logs.

11. **Loop back on mismatch**
   - Wrong framework -> identify again.
   - Wrong ERD/database -> return to database planning.
   - Failed migration -> fix schema/migration.
   - Bad generated files -> inspect generator plan and regenerate carefully.
   - Broken routes/auth/UI -> complete/audit again.
   - Failed verification -> test, fix, and retest.

12. **Handoff clearly**
   - Report what was inspected, generated, edited, tested, not tested, and what the user must run manually.


## Framework Role For System Website Project Builder

This kit owns the implementation loop after the ERD/database is approved.

- Guide beginners through setup, database connection, migrations/imports, pilot generation, full generation, post-generation audit, and browser testing.
- For CakePHP, run or guide `bin/cake` checks, then pilot Bake one table before `bake all` on approved tables.
- For Laravel, run or guide Artisan checks, then generate resources after migration/schema planning.
- Treat Artisan/Bake output as scaffold only. Complete validation, relationships, auth, role checks, business logic, UI, routes, and verification before saying the feature is done.
