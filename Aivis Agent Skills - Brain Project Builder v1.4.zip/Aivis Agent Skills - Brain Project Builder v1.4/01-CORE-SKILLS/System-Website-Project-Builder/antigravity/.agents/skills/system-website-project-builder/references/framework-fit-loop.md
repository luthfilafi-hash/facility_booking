
# Stable Loop Reference

This reference extends Aivis Aivis Agent Skills - Brain Project Builder v1.4 for Laravel, Laravel Artisan, CakePHP, and CakePHP Bake projects.

## Goal

Keep the same Aivis logic - inspect first, database-first, risk gates, UI confirmation, security, and verification - while adapting the implementation path to the active framework.

## When To Use

Use this reference when:

- The user says Laravel, Artisan, Eloquent, Blade, `php artisan`, migrations, seeders, factories, policies, form requests, or `Route::resource`.
- The project has Laravel files such as `artisan`, `routes/web.php`, `app/Http/Controllers`, `app/Models`, or `database/migrations`.
- The user says CakePHP, Bake, Cake ORM, `bin/cake`, Cake migrations, table/entity/controller/templates, or `bake all`.
- The project has CakePHP files such as `bin/cake`, `src/Controller`, `src/Model/Table`, `src/Model/Entity`, `templates`, `config/routes.php`, or `webroot`.

## Fit Loop Checklist

| Step | Check | Pass Condition |
| --- | --- | --- |
| 1 | Framework identify | Plain PHP, Laravel, CakePHP, or other stack is clearly stated. |
| 2 | Version/environment | PHP, Composer, framework package, local server, and generator availability are known or manual commands are provided. |
| 3 | Aivis phase mapping | Database, coding, and verification phases are mapped to framework conventions. |
| 4 | Database-first gate | Migrations/schema/table shape are inspected or confirmed before scaffold generation. |
| 5 | Generator plan | Artisan or Bake commands match the intended tables/features. |
| 6 | Scaffold generation | Files are generated only after schema/risk gates are satisfied. |
| 7 | Post-scaffold audit | Generated models, controllers, routes, views/templates, validation, and relationships are inspected. |
| 8 | Completion pass | Missing business logic, auth/roles, validation, UI, security, and error states are completed. |
| 9 | Verification pass | Routes, migrations, CRUD, auth/roles, validation, UI, and logs are checked where possible. |
| 10 | Loop back | Any mismatch returns to the correct earlier step instead of random patching. |

## Laravel Fit Notes

- Use Artisan for generated models, migrations, controllers, form requests, policies, factories, and seeders when appropriate.
- Use migrations as the main database source unless the user asks for raw SQL or phpMyAdmin import.
- Use Eloquent relationships and Laravel validation instead of scattering manual SQL in views.
- Verify with commands such as `php artisan migrate:status`, `php artisan route:list`, and relevant browser/manual flow checks.

## CakePHP Fit Notes

- Use CakePHP conventions before custom configuration.
- Use Bake after tables/migrations are ready.
- Bake output must be audited and completed; `bake all` is not the finish line.
- Verify routes, controller actions, ORM associations, templates, validation, and auth/role access.

## Required Final Report For Framework Work

For Laravel/CakePHP tasks, final summaries should include:

```text
Framework:
Generator used:
Commands/files changed:
Database/migration status:
Routes/controllers/templates checked:
Auth/security checks:
Manual checks still required:
```


## Recheck Patch: Framework Readiness Commands

Use this patch as the practical command checklist for v1.4 framework projects.

### Laravel Readiness

Run or ask the user to run these before generating framework files:

```bash
composer show laravel/framework
php artisan --version
php artisan list
php artisan migrate:status
php artisan route:list
```

If the task needs full CRUD with validation, prefer commands that also create form requests:

```bash
php artisan make:controller ProductController --model=Product --resource --requests
php artisan make:request StoreProductRequest
```

Laravel verification must include route list, migration status, Eloquent relationships, mass assignment, form request authorization/rules, Blade `@csrf`, middleware/auth access, redirects, validation errors, and CRUD flow.

### CakePHP Readiness

Run or ask the user to run these before Bake:

```bash
composer show cakephp/cakephp
composer show cakephp/bake
composer show cakephp/migrations
bin/cake
bin/cake routes
bin/cake migrations status
```

On Windows, use `bin\cake`.

If Bake is missing:

```bash
composer require --dev cakephp/bake
```

If Migrations is missing:

```bash
composer require cakephp/migrations "@stable"
bin/cake plugin load Migrations
```

CakePHP verification must include `bin/cake routes`, `bin/cake migrations status`, database connection, Table/Entity/Controller/Templates audit, ORM associations, validation/defaultRules, entity `$_accessible`, FormHelper/CSRF/form protection, escaping, redirects, flash messages, pagination, and CRUD flow.

### Antigravity Extra Safety

When using Antigravity, install the native skill folder when possible:

```text
<project-root>/.agents/skills/system-website-project-builder/SKILL.md
```

Keep `.antigravityrules` as the always-on rule layer, but use the native Skill folder for discoverable project-specific framework behavior.


## CakePHP Beginner Guided Workflow Addendum

When the user is new to CakePHP, do not only say "run Bake". Guide them through the beginner-safe sequence:

1. Explain the CakePHP terms briefly: Composer, `bin/cake`, migration, Bake, Table class, Entity, Controller, Template.
2. Identify whether this is a new CakePHP app, an existing CakePHP app, a conversion, or a framework mismatch.
3. Check environment and tools with `php -v`, `composer -V`, `composer show cakephp/cakephp`, `composer show cakephp/bake`, `composer show cakephp/migrations`, and `bin/cake` / `bin\cake`.
4. Verify the ERD before Bake: tables, primary keys, foreign keys, junction tables, required fields, timestamps, indexes, statuses, and delete/update behavior.
5. Confirm the database status as `migrated`, `imported`, or `not created yet`.
6. For beginners, bake one simple table first as a pilot check before baking every table.
7. Bake all approved tables only after the pilot bake succeeds and the database connection works.
8. After Bake, inspect generated Table, Entity, Controller, and Template files.
9. Complete associations, validation, `buildRules()`, `$_accessible`, auth, role checks, ownership checks, redirects, flash messages, UI, empty states, and security.
10. Test CRUD, validation errors, navigation, auth, role access, and direct URL protection.

After `bin/cake bake all TableName`, the next step is always post-Bake completion:

```text
Bake all approved tables
→ inspect generated files
→ fix associations and validation
→ add auth/role/business logic
→ improve UI/templates
→ verify routes
→ browser-test CRUD
→ fix errors
→ final security and deployment check
```

Read `references/cakephp-beginner-guided-workflow.md` when available.

