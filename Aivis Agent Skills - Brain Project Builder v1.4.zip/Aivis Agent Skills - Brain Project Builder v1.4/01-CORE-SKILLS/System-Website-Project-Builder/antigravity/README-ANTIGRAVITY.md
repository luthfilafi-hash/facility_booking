# Antigravity Installation

Use this folder when installing Aivis Agent Skills - Brain Project Builder v1.4 into Google Antigravity.

## Recommended Install

Install both layers when possible:

1. `.antigravityrules` - always-on project rules and safety gates.
2. `.agents/skills/system-website-project-builder/SKILL.md` - native Antigravity Skill for on-demand framework workflow logic.

## Project-Scope Install

Copy or merge `.antigravityrules` into the project root.

Then copy the skill folder:

```text
antigravity/.agents/skills/system-website-project-builder/
```

into:

```text
<project-root>/.agents/skills/system-website-project-builder/
```

After installation, ask Antigravity:

```text
What skills are available?
```

Or in Antigravity CLI, use:

```text
/skills
```

The `system-website-project-builder` skill should appear. If it does not appear, restart/reload the workspace and confirm the folder path.

## First Test

```text
Use the System Website Project Builder rules.
Inspect this project first.
Tell me the mode, primary kit, supporting kit rules, risk level, current phase, next phase, and whether you can proceed or need confirmation.
```

## Laravel/CakePHP Test

```text
Use the system-website-project-builder skill.
This project uses Laravel/CakePHP.
Run the Stable Loop first.
Do not run Artisan/Bake or migrations until database, environment, and risk gates are clear.
```

The agent should use Adaptive Mode, risk gates, prototype labels, scope-aware verification, Laravel/CakePHP readiness commands, and Antigravity command safety gates.

## CakePHP beginner guidance note

This v1.4 patch includes `references/cakephp-beginner-guided-workflow.md` so Antigravity guides new users through ERD checks, migrations/imports, pilot Bake, full Bake, post-Bake audit, auth/business logic, UI, security, and CRUD verification.

