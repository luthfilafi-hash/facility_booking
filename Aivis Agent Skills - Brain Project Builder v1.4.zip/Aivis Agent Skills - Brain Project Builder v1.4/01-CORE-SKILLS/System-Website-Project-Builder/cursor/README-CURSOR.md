# Cursor Installation

Use this folder when installing Aivis Agent Skills - Brain Project Builder v1.4 into Cursor.

## Install

Copy `cursor/.cursor/rules/system-website-project-builder.mdc` into the target project's `.cursor/rules/` folder. Preserve existing project-specific rules.

## First Test

```text
Use the System Website Project Builder rules.
Inspect this project first.
Tell me the mode, primary kit, supporting kit rules, risk level, current phase, next phase, and whether you can proceed or need confirmation.
```

Cursor should use Adaptive Mode, risk gates, prototype labels, and scope-aware verification.
