# Buyer Checklist

Use this checklist after installing the System Website Project Builder core skill into an AI coding agent.

## Installation Check

- The correct adapter is installed for the buyer's tool:
  - Codex: `codex/system-website-project-builder/`
  - Claude Code: `CLAUDE.md`
  - Antigravity: `.antigravityrules`
  - Cursor: `.cursor/rules/system-website-project-builder.mdc`
  - ChatGPT/custom instructions: `chatgpt/PROJECT-INSTRUCTIONS.md`
  - Generic AI: `AGENTS.md`
- Existing project rules were merged instead of blindly overwritten.
- No private credentials, API keys, cookies, database passwords, or hosting secrets were copied into the kit files.
- The buyer knows which quick-start prompt to use first.

## First Test

Run the universal activation prompt from `QUICK-START-PROMPTS.md`.

The agent should:

- Inspect the project before coding.
- Show mode, primary kit, supporting kit rules, risk level, current phase, next phase, and whether it is proceeding or waiting.
- Use low, medium, and high risk gates.
- Ask only missing choices that materially affect the task.
- Ask about theme, colors, style, and layout before major UI work.
- Follow the actual database for existing/client-safe work.
- Allow proposed schema only when clearly labeled `proposed`.
- Avoid presenting proposed paths, tables, columns, roles, helpers, credentials, or deployment targets as confirmed facts.

## Risk Gate Check

The agent is following v1.4 well if:

- Low-risk tasks move quickly after inspection.
- Medium-risk tasks proceed with labeled assumptions or compact questions.
- High-risk tasks pause before implementation.

High-risk work includes auth, admin permissions, payment, checkout, orders, stock, uploads, production deployment, DNS, secrets, destructive database changes, live accounts, credential SQL, final production schema, full replacement upload, and major architecture/layout replacement.

## Website Build Quality

For a new or improved website, check that the agent handled:

- Pages and navigation.
- Responsive HTML/CSS.
- JavaScript interactions and failure states.
- Backend request handling.
- Database reads and writes.
- Validation and error messages.
- Auth and roles when needed.
- Admin or management workflows when data needs managing.
- Verification notes.

## Security Check

The agent should use or preserve:

- Prepared statements for user-controlled values.
- Password hashing for account passwords.
- Server-side role checks.
- CSRF protection for state-changing forms when sessions/cookies are used.
- Output escaping for dynamic HTML.
- Upload validation for user files.
- Secret-safe configuration.

## Style/UI Confirmation Check

For small UI maintenance, the agent should inspect and proceed when clear.

For redesigns, new themes, page templates, or major CSS/layout changes, the agent should ask:

- Keep old design or redesign?
- Color direction?
- Typography/font direction?
- Layout direction?
- Product/card/list/table/admin style?
- Preserve existing CSS?
- Reuse existing images/assets?
- Match the old version visually?

## Deployment Check

The agent should first detect the deployment target.

For shared PHP hosting, it should provide changed-file uploads, SQL import decisions, config/secrets warnings, media preservation notes, PHP version/extension notes, and smoke tests.

For modern deployment, it should provide provider-specific build commands, output directories, environment variable checks, routing fallback notes, production/preview URL checks, deployment logs, and rollback notes.

## Verification Check

The final report should match the task scope:

- Small UI changes: relevant UI checks only.
- Database work: table/column/schema/query checks.
- Auth/admin/shop/upload/payment work: relevant flow checks.
- Deployment or final ZIP/package: full verification matrix.

## Red Flags

The kit is not being followed well if the agent:

- Starts coding before inspecting affected files.
- Blocks tiny UI/copy changes behind a full planning process.
- Redesigns major UI without asking style direction.
- Presents proposed schema as confirmed.
- Continues production/client coding after finding missing or inconsistent database information.
- Relies only on JavaScript for security or validation.
- Claims tests passed without running them.
- Claims final ZIP/package is ready before relevant CSS, JavaScript, images, links, redirects, database files, and path behavior are checked or marked not available.
- Suggests full reupload or full database import without explaining why.
- Stores secrets in project files or instructions.

## Framework Buyer Check

If the project uses Laravel or CakePHP, database-first work must be expressed through the framework schema path:

- Laravel: migrations, Eloquent model relationships, seeders/factories when needed, and route/controller validation.
- CakePHP: migrations or confirmed tables, ORM associations, Table/Entity validation, and Bake only after schema is ready.

Do not generate Artisan/Bake files before the database shape is inspected, proposed, or confirmed according to the active risk level.


## Antigravity Stable Checklist

- [ ] `.antigravityrules` is copied or merged into the project root.
- [ ] Antigravity native Skill folder installed at `<project-root>/.agents/skills/system-website-project-builder/`.
- [ ] Antigravity confirms the skill is visible through `What skills are available?` or `/skills`.
- [ ] Laravel/CakePHP framework is identified before code generation.
- [ ] Artisan/Bake commands are shown as a command plan before execution.
- [ ] Migration status and route checks are included in the final report.
