# Database First Checklist

Use this checklist before an AI agent builds features that read from or write to a database.

## Goal

The agent must separate confirmed database truth from proposed design.

For existing, client-safe, production, or graded work, the agent must follow the user's actual database or ask the user to confirm the correct database structure before implementation.

For Prototype Mode, the agent may propose tables, columns, relationships, statuses, roles, and ownership rules when useful, but must label them `proposed`.

## Inspect First

Before database-backed coding, the agent should inspect available project truth:

- Database config files.
- Existing connection/query helpers.
- SQL dumps.
- Migration files.
- Seed files.
- Model/entity files.
- Existing queries in PHP/API/controllers.
- Admin pages that manage the same data.
- Forms that submit related data.
- XML, XSD, XSLT, JSON, CSV, static HTML, or old data files used as source truth in conversions.

## Confirm These With The User When Unclear

Ask the user to confirm when the information affects client-safe or production implementation:

- Table names.
- Each table purpose.
- Column/attribute names.
- Required and optional fields.
- Field types and lengths when important.
- Primary keys.
- Foreign keys and relationships.
- Allowed status values.
- User roles and permissions.
- Record ownership rules.
- Whether records should be deleted, archived, disabled, or soft-deleted.
- Data source for each table/column.
- Which fields are from the original project.
- Which fields are proposed.
- Which fields need approval.
- Whether the database already exists or must be created.
- Whether the schema dump/migration should be updated.

## Prototype Mode

In Prototype Mode, the agent may suggest common defaults such as:

- `id`
- `created_at`
- `updated_at`
- `status`
- `role`
- common foreign keys like `user_id`, `product_id`, or `order_id`

These must be labeled `proposed` until approved.

## High-Risk Stop Conditions

The agent should pause and ask before implementation when:

- Existing code and schema conflict.
- A production/client feature requires a new table or column that the user has not approved.
- Existing table/column names are ambiguous.
- Status values or role names are unclear.
- The relationship between records is unclear.
- The feature changes checkout, payment, auth, permissions, inventory, uploads, or admin approval data.
- Credential SQL, seed users, password hashes, or live accounts would be created.

## Database Confirmation Sheet

Require this before final SQL generation for client-safe or production work:

```text
Database name:

Table:
Purpose:
Columns:
Primary key:
Foreign keys:
Nullable fields:
Unique fields:
Enum/status values:
Relationships:
Source:
Original fields:
Proposed fields:
Needs approval:
```

## Ready To Code Criteria

The agent may proceed when:

- The task is low-risk and does not depend on the database.
- The task is prototype work and unconfirmed decisions are labeled `proposed`.
- The relevant tables and attributes are discovered or confirmed for existing/client-safe work.
- Required relationships are known.
- Role and ownership rules are known.
- Schema changes are approved when needed.
- The agent knows whether to update SQL dumps or migrations.

## Final Report

When database work is involved, the agent should report:

- Tables used.
- Columns/attributes used.
- Confirmed versus proposed schema decisions.
- Schema changes made or proposed.
- SQL dump/migration updates made or skipped.
- Database checks run.
- Any database assumptions that remain.

## Framework Database Rule

If the project uses Laravel or CakePHP, database-first work must be expressed through the framework schema path:

- Laravel: migrations, Eloquent model relationships, seeders/factories when needed, and route/controller validation.
- CakePHP: migrations or confirmed tables, ORM associations, Table/Entity validation, and Bake only after schema is ready.

Do not generate Artisan/Bake files before the database shape is inspected, proposed, or confirmed according to the active risk level.
