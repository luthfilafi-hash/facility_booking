# Version

Current version: `1.4`

## What Version 1.4 Means

This kit keeps the the adaptive safety and speed model, then adds a framework-fit layer for Laravel, Laravel Artisan, CakePHP, and CakePHP Bake.

Version 1.4 adds:

- Stable Loop for Laravel/CakePHP detection, mapping, generation, post-scaffold audit, completion, verification, and loop-back fixes.
- Laravel Adapter Rules for Artisan, migrations, Eloquent, controllers, form requests, policies, seeders, factories, Blade, auth, CSRF, and route verification.
- CakePHP Adapter Rules for Bake, migrations, table/entity/controller/template conventions, ORM associations, validation, auth, CSRF, escaping, and route verification.
- Generator warning: Artisan/Bake output is scaffold only, not a finished feature.
- Framework-specific quick-start prompts for Laravel Artisan and CakePHP Bake.

Version 1.4 still requires confirmation for high-risk client/production work such as auth, admin permissions, payment, checkout, orders, stock, uploads, secrets, live accounts, final production schema, destructive database changes, and deployment.

## Recommended Release Label

Use this label when sharing the package:

```text
Aivis Agent Skills - Brain Project Builder v1.4
```


## Recheck Patch

`v1.4 - Antigravity QA Patch` adds native Antigravity Skill packaging, stronger Artisan/Bake readiness checks, CakePHP plugin fallback handling, route/migration verification commands, and safer Antigravity command gates.

<!-- AIVIS_V14_ALL_SKILLS_VERSION_PATCH -->
## v1.4 All-Skills Framework Completion Patch

Patch label: `v1.4 All-Skills Framework Completion Patch`.

This patch adds Laravel/CakePHP role awareness across every kit and every AI adapter, including Antigravity native skill packaging where applicable.
