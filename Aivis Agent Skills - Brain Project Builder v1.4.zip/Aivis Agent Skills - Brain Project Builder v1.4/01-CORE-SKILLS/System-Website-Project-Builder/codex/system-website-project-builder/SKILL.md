---
name: system-website-project-builder
description: Adaptive full-stack website project builder and maintainer for PHP/MySQL-first projects, Laravel, CakePHP, and discovered web stacks. Use when an agent needs to create, convert, improve, style, debug, secure, verify, prototype, maintain, or deploy websites, ecommerce or bundle shop sites, admin/business apps, HTML/CSS/JavaScript interfaces, PHP backends, MySQL schemas, source conversions from XML/XSD/XSLT/JSON/CSV/static HTML, Laravel Artisan workflows, CakePHP Bake workflows, auth and roles, dashboards, CRUD workflows, forms, uploads, local path checks, modern or shared-hosting deployment, or project handoff; supports Adaptive, Client-Safe, Prototype, Maintenance, Audit, and Deployment modes.
---

# System / Website Project Builder

## Purpose

Use this skill to help an AI agent build or maintain a complete website project. Default to `Adaptive Mode`: inspect first, choose the right risk level, proceed quickly for low-risk work, and pause for high-risk or production/client decisions.

The default fallback stack is PHP, MySQL, HTML, CSS, and JavaScript on a Laragon-style local environment, but the agent must follow the actual stack, structure, and deployment target discovered in the project.

Keep the guidance agent-neutral. Do not assume a specific assistant, IDE, shell, browser, or hosting account unless the active task or project reveals it.

## Core Workflow

1. Choose the mode and risk level.
   Start non-trivial work by naming mode, primary kit, supporting kit rules, risk level, current phase, next phase, and whether the agent is proceeding or waiting. Read [workflow-modes.md](references/workflow-modes.md), [risk-gates.md](references/risk-gates.md), and [kit-orchestration.md](references/kit-orchestration.md).

2. Discover before deciding.
   Inspect the project structure, entrypoints, configuration, database access, assets, routes, helper functions, and deployment files before choosing an implementation approach. Read [project-discovery.md](references/project-discovery.md).

3. Use database rules appropriate to the mode.
   In existing/client-safe work, confirm unclear tables, attributes, relationships, statuses, roles, ownership rules, and schema updates before coding. In Prototype Mode, proposed schemas are allowed when clearly labeled. Read [database-first.md](references/database-first.md) and [prototype-mode.md](references/prototype-mode.md).

4. Confirm style only when the task needs it.
   Small UI maintenance can proceed after inspection. Redesigns, new themes, page-template work, or major CSS changes need style confirmation. Read [style-ui-confirmation.md](references/style-ui-confirmation.md).

5. Ask key choices first, but only when they matter.
   Before creating a new site, redesigning UI, or making broad feature decisions, ask the choices that affect the build: purpose, audience, pages/features, theme, colors, style, typography, data, roles, and deployment target. Use [website-intake.md](references/website-intake.md).

6. Preserve local conventions.
   Match the existing folder structure, naming, PHP style, database helper APIs, CSS organization, JavaScript style, UI language, and build/deploy tooling unless the user explicitly asks for a migration or redesign.

7. Build complete behavior.
   A feature should connect the relevant UI, server handling, database changes, auth/role checks, validation, errors, empty states, and verification path.

8. Apply the security baseline.
   Use prepared statements, password hashing, output escaping, CSRF protection for state-changing forms, server-side validation, safe sessions, guarded uploads, and secret-safe configuration. Read [security-auth.md](references/security-auth.md).

9. Check local and deployment paths when relevant.
   For Laragon/PHP projects, check folder URL and virtual host behavior when possible. For deployment tasks, detect whether the target is shared hosting, static hosting, Git/cloud, Docker, CI/CD, or VPS/cloud. Read [laragon-local-paths.md](references/laragon-local-paths.md) and [modern-deployment-targets.md](references/modern-deployment-targets.md).

10. Verify in proportion to scope.
   Simple changes need focused checks. Full builds, releases, deployments, and final ZIP delivery need the full matrix. Read [scope-aware-verification.md](references/scope-aware-verification.md), [verification-matrix.md](references/verification-matrix.md), and [verification-and-deployment.md](references/verification-and-deployment.md).

## Reference Guide

- For workflow modes: [workflow-modes.md](references/workflow-modes.md).
- For low/medium/high risk gates: [risk-gates.md](references/risk-gates.md).
- For combining kits on one task: [kit-orchestration.md](references/kit-orchestration.md).
- For fast MVP work: [prototype-mode.md](references/prototype-mode.md).
- For unknown or existing projects: [project-discovery.md](references/project-discovery.md).
- For database/entity/attribute confirmation: [database-first.md](references/database-first.md).
- For style/UI confirmation before coding: [style-ui-confirmation.md](references/style-ui-confirmation.md).
- For initial user questions and design direction: [website-intake.md](references/website-intake.md).
- For HTML, CSS, JavaScript, responsive UI, and styling: [frontend-html-css-js.md](references/frontend-html-css-js.md).
- For PHP, MySQL, Laragon, migrations, and SQL dumps: [php-mysql-laragon.md](references/php-mysql-laragon.md).
- For auth, roles, sessions, validation, escaping, uploads, and secrets: [security-auth.md](references/security-auth.md).
- For bundle shops and ecommerce flows: [ecommerce-bundles.md](references/ecommerce-bundles.md).
- For admin dashboards, CRUD, reports, approvals, and management tools: [admin-business-apps.md](references/admin-business-apps.md).
- For Laragon path and asset checks: [laragon-local-paths.md](references/laragon-local-paths.md).
- For modern deployment targets: [modern-deployment-targets.md](references/modern-deployment-targets.md).
- For scoped final reporting: [scope-aware-verification.md](references/scope-aware-verification.md).
- For final verification matrix: [verification-matrix.md](references/verification-matrix.md).
- For smoke tests, browser checks, deployment, and final handoff: [verification-and-deployment.md](references/verification-and-deployment.md).

## Default Build Priorities

- Start with the usable product, not a marketing shell, unless the user asks for a landing page.
- Keep momentum on low-risk work.
- Pause only for high-risk decisions or unclear medium-risk work that materially changes the outcome.
- Label proposals as `proposed`; do not present them as confirmed facts.
- Make common workflows complete: login, navigation, forms, list/detail pages, admin actions, feedback states, and error handling.
- Use semantic HTML and accessible controls.
- Keep CSS responsive, organized, and reusable.
- Keep JavaScript progressive and resilient; server-side validation remains authoritative.
- Keep database changes intentional and reflected in dumps or migration notes when the project uses them.
- Use reusable base URL/asset path handling for PHP projects instead of fragile hardcoded paths.
- Prefer changed-file deployments over full replacement uploads unless a full reset is intended.

## What To Avoid

- Do not invent confirmed project paths, table names, columns, roles, helpers, credentials, or deployment targets.
- Do not block small low-risk changes behind enterprise-level confirmation.
- Do not make final production schema, auth, payment, stock, upload, credential, or deployment decisions without confirmation.
- Do not store plaintext passwords, API keys, cookies, or hosting credentials in skill files or repository files.
- Do not replace a project's architecture with a new framework unless the user asks for that migration.
- Do not replace old CSS/layout or old page behavior without confirmation.
- Do not treat JavaScript-only filtering, client-only validation, or hidden UI state as a substitute for correct server-side data handling.
- Do not generate or claim a final ZIP is ready until relevant CSS, JavaScript, images, links, redirects, database files, and path behavior are checked or explicitly marked not available.

## Stable Loop

Use this loop whenever the user requests Laravel, Laravel Artisan, CakePHP, CakePHP Bake, or whenever the inspected project clearly contains those frameworks.

The default fallback stack is still PHP/MySQL/HTML/CSS/JavaScript, but a requested or detected framework becomes the active architecture. Do not force plain PHP file structure when Laravel or CakePHP is active.

### Loop Trigger Detection

Detect the requested or existing framework before coding:

- Laravel signs: `artisan`, `composer.json` with `laravel/framework`, `app/Http/Controllers`, `app/Models`, `routes/web.php`, `database/migrations`, Blade views.
- Laravel Artisan signs: user asks for `php artisan`, `make:model`, `make:controller`, `make:migration`, `migrate`, `db:seed`, `Route::resource`, or Eloquent.
- CakePHP signs: `bin/cake`, `composer.json` with `cakephp/cakephp`, `src/Controller`, `src/Model/Table`, `src/Model/Entity`, `templates/`, `config/routes.php`, `webroot/`.
- CakePHP Bake signs: user asks for `bake`, `bin/cake bake`, `bake all`, model/controller/template/test generation, Cake migrations, or Cake ORM scaffolding.

### The Loop

Repeat the loop until the project, database, generated files, routes, security, UI, and verification all match the active framework.

1. Framework Identify
   - Confirm whether the project is plain PHP, Laravel, CakePHP, or another stack.
   - If the user explicitly requests Laravel or CakePHP, treat that as the active framework unless it conflicts with an existing project.

2. Version And Environment Check
   - Inspect framework version, PHP version, Composer dependencies, `.env` or config files, local server target, and available generator commands.
   - If the version cannot be checked, state that and write commands the user can run.

3. Aivis Phase Mapping
   - Keep Aivis phases, but map implementation to the framework:
     - Database Planning -> migrations/schema files.
     - Coding/Conversion -> controllers, models, views/templates, routes, middleware, validation, services, and framework helpers.
     - Verification -> framework route list, migration status, CRUD flow, auth/role checks, logs, and manual browser checks.

4. Database-First Gate
   - Inspect or design the database first.
   - For existing/client-safe work, pause before final production schema, destructive migrations, auth/role/payment/order/upload changes, or credential changes.
   - For Prototype Mode, proposed migrations are allowed when clearly labeled `proposed`.

5. Generator Plan
   - Choose the correct generator path:
     - Laravel -> Artisan commands.
     - CakePHP -> Bake commands.
   - Show the planned commands before running or writing scaffold files when the change is medium/high risk.

6. Scaffold Generation
   - Generate only after the database/migration shape is aligned.
   - Laravel should prefer Artisan for models, migrations, controllers, requests, policies, seeders, factories, and resources.
   - CakePHP should prefer Bake for model/table/entity, controller, templates, tests, and `bake all` after tables exist.

7. Post-Scaffold Audit
   - Treat generated files as a starting point, not finished work.
   - Inspect generated models/entities, tables, controllers, requests, validation, routes, templates/views, associations/relationships, mass assignment rules, and tests.

8. Completion Pass
   - Add missing validation, relationships, authorization, role checks, UI consistency, redirects, empty states, error handling, upload guards, CSRF usage, escaping, and transactions where relevant.

9. Verification Pass
   - Check route availability, migration status, CRUD flow, database reads/writes, auth/role access, validation errors, UI rendering, and logs where possible.
   - Only claim checks that were actually performed.

10. Loop Back On Mismatch
   - If any mismatch is found, return to the matching step instead of patching randomly:
     - Wrong framework -> Step 1.
     - Version/tooling issue -> Step 2.
     - Wrong database/migration -> Step 4.
     - Wrong generator/output -> Step 5 or 6.
     - Broken routes/views/auth/security -> Step 7 or 8.
     - Failed verification -> Step 9.

### Laravel Adapter Rules

When Laravel is active:

- Use Laravel conventions for routes, controllers, models, migrations, seeders, factories, middleware, policies, form requests, Blade views, validation, sessions, auth, CSRF, Eloquent relationships, storage, and `.env` configuration.
- Prefer migrations over raw SQL unless the user specifically asks for SQL export or phpMyAdmin import.
- Prefer Eloquent and query builder conventions instead of manual `mysqli` or raw PDO scattered through views.
- Use Artisan generation when it is safer than manually creating files.
- Inspect generated files after Artisan runs; do not say the feature is complete only because the command created files.
- Common command examples:
  - `php artisan make:model Product -m`
  - `php artisan make:model Product -a`
  - `php artisan make:controller ProductController --resource`
  - `php artisan make:migration create_products_table`
  - `php artisan migrate`
  - `php artisan db:seed`
  - `php artisan route:list`

### CakePHP Adapter Rules

When CakePHP is active:

- Use CakePHP conventions for controllers, table classes, entities, templates, routes, validation, ORM associations, migrations, CSRF, escaping, authorization/authentication, and configuration.
- Prefer Bake after the tables/migrations are confirmed.
- Follow naming conventions carefully:
  - Tables: plural snake_case database tables.
  - Controllers: plural names such as `ProductsController`.
  - Table classes: plural names such as `ProductsTable`.
  - Entities: singular names such as `Product`.
  - Foreign keys: usually end with `_id`.
- Inspect Bake output; do not treat `bake all` as complete production code.
- Common command examples:
  - `composer create-project --prefer-dist cakephp/app my_app`
  - `bin/cake bake migration CreateProducts`
  - `bin/cake migrations migrate`
  - `bin/cake bake model Products`
  - `bin/cake bake controller Products`
  - `bin/cake bake template Products`
  - `bin/cake bake all Products`

### Framework Scaffold Warning

Laravel Artisan and CakePHP Bake are accelerators, not final quality guarantees. After generation, the agent must still complete validation, relationships, auth/role logic, UI consistency, error states, security checks, database verification, route testing, and manual flow testing.


## Antigravity Framework QA Addendum

Use this addendum whenever the task involves Laravel, Laravel Artisan, CakePHP, CakePHP Bake, or any generator command inside Antigravity.

### Antigravity Native Installation

For best Antigravity behavior, install both layers when possible:

1. Always-on workspace rule:
   - Copy `antigravity/.antigravityrules` into the project root or merge it into the existing Antigravity rules file.
2. On-demand Antigravity Skill:
   - Copy `antigravity/.agents/skills/system-website-project-builder/` into `<project-root>/.agents/skills/system-website-project-builder/`.
   - Then ask Antigravity: `What skills are available?` or use `/skills` in Antigravity CLI to verify that the skill is visible.

If only one layer is available, prefer the native Skill folder for project-specific workflow logic and keep `.antigravityrules` for always-on safety gates.

### Antigravity Command Safety

Before running terminal commands that generate, modify, migrate, delete, seed, or overwrite files/data, show:

```text
Command plan:
Affected files/tables:
Risk level:
Rollback or backup step:
Proceeding or waiting for confirmation:
```

Do not run destructive or broad commands without explicit approval. This includes destructive migrations, database resets, seeders that overwrite data, recursive delete commands, forced overwrites, production deployment commands, credential changes, and bulk file replacements.

### Laravel Artisan Readiness Check

Before Artisan generation, inspect or ask the user to run:

```bash
composer show laravel/framework
php artisan --version
php artisan list
php artisan migrate:status
php artisan route:list
```

Use Laravel generators only after the database/migration shape is clear. Prefer:

```bash
php artisan make:model Product -m
php artisan make:model Product -a
php artisan make:controller ProductController --model=Product --resource --requests
php artisan make:request StoreProductRequest
php artisan migrate
php artisan route:list
```

After generation, verify Eloquent relationships, `$fillable`/`$guarded`, form request `authorize()` and `rules()`, Blade `@csrf`, route model binding, middleware/auth, validation messages, redirects, empty states, and CRUD browser flow.

### CakePHP Bake Readiness Check

Before Bake generation, inspect or ask the user to run:

```bash
composer show cakephp/cakephp
composer show cakephp/bake
composer show cakephp/migrations
bin/cake
bin/cake routes
bin/cake migrations status
```

On Windows, use `bin\cake` instead of `bin/cake`.

If Bake is not available, propose this before baking:

```bash
composer require --dev cakephp/bake
```

If Migrations is missing, propose this before migration work:

```bash
composer require cakephp/migrations "@stable"
bin/cake plugin load Migrations
```

Use Bake only after the table/migration shape is ready and the database connection works. Prefer:

```bash
bin/cake bake migration CreateProducts
bin/cake migrations migrate
bin/cake bake model Products
bin/cake bake controller Products
bin/cake bake template Products
bin/cake bake all Products
bin/cake routes
```

After baking, verify `src/Model/Table/*Table.php`, `src/Model/Entity/*.php`, `src/Controller/*Controller.php`, `templates/*`, associations, validation/defaultRules, entity `$_accessible`, FormHelper usage, CSRF/form protection, escaping, flash messages, redirects, empty states, pagination, route checks, and CRUD browser flow.

### Framework Mismatch Rule

If the project is detected as Laravel but the user asks for CakePHP, or detected as CakePHP but the user asks for Laravel, stop before generating files. Explain the conflict and ask whether this is a conversion, a new separate app, or a mistake.


## CakePHP Beginner Guided Workflow Addendum

When the user is new to CakePHP, do not only say "run Bake". Guide them through the beginner-safe sequence:

1. Explain the CakePHP terms briefly: Composer, `bin/cake`, migration, Bake, Table class, Entity, Controller, Template.
2. Identify whether this is a new CakePHP app, an existing CakePHP app, a conversion, or a framework mismatch.
3. Check environment and tools with `php -v`, `composer -V`, `composer show cakephp/cakephp`, `composer show cakephp/bake`, `composer show cakephp/migrations`, and `bin/cake` / `bin\cake`.
4. Verify the ERD before Bake: tables, primary keys, foreign keys, junction tables, required fields, timestamps, indexes, statuses, and delete/update behavior.
5. Confirm the database status as `migrated`, `imported`, or `not created yet`.
6. For beginners, bake one simple table first as a pilot check before baking every table.
7. Bake all approved tables only after the pilot bake succeeds and the database connection works.
8. After Bake, inspect generated Table, Entity, Controller, and Template files.
9. Complete associations, validation, `buildRules()`, `$_accessible`, auth, role checks, ownership checks, redirects, flash messages, UI, empty states, and security.
10. Test CRUD, validation errors, navigation, auth, role access, and direct URL protection.

After `bin/cake bake all TableName`, the next step is always post-Bake completion:

```text
Bake all approved tables
→ inspect generated files
→ fix associations and validation
→ add auth/role/business logic
→ improve UI/templates
→ verify routes
→ browser-test CRUD
→ fix errors
→ final security and deployment check
```

Read `references/cakephp-beginner-guided-workflow.md` when available.
<!-- AIVIS_V14_ALL_SKILLS_FRAMEWORK_PATCH -->
## Aivis v1.4 All-Skills Framework Completion Loop

Use this loop whenever the project requests or detects Laravel, Laravel Artisan, CakePHP, CakePHP Bake, or any framework-generated website workflow.

The agent must not stop at `php artisan make:*` or `bin/cake bake *`. Generated files are only the scaffold. Aivis must guide the beginner, confirm the database/ERD, generate safely, then complete, secure, style, test, and hand off the work.

### Beginner Guidance Rule

When the user is new to Laravel or CakePHP, explain the current step in simple words before giving commands. For each command, state:

- what the command does;
- where to run it;
- what success roughly looks like;
- what to check next;
- what not to run without backup or confirmation.

### Full Framework Flow

1. **Identify the framework**
   - Laravel signs: `artisan`, `laravel/framework`, `routes/web.php`, `app/Models`, `app/Http/Controllers`, `database/migrations`, Blade views.
   - CakePHP signs: `bin/cake`, `cakephp/cakephp`, `src/Controller`, `src/Model/Table`, `src/Model/Entity`, `templates`, `config/routes.php`, `webroot`.

2. **Check local setup**
   - PHP version, Composer install, framework version, database config, local server target, and command availability.
   - If the AI cannot run commands, give the user safe commands to copy and ask them to paste the output.

3. **Check the ERD/database first**
   - Confirm tables, primary keys, foreign keys, nullable fields, unique fields, statuses, role fields, timestamps, indexes, and relationships.
   - Do not bake/generate from a weak ERD. Fix the ERD or migration plan first.

4. **Create/apply schema safely**
   - Laravel: prefer migrations and `php artisan migrate`.
   - CakePHP: prefer migrations or confirmed SQL import, then `bin/cake migrations migrate` where migrations are used.
   - Do not reset/drop/overwrite real data without explicit confirmation and backup.

5. **Pilot generation first**
   - Generate one simple table/resource first.
   - Inspect the generated output before generating all files.
   - Only continue if naming, routes, templates/views, model/entity/table class, validation, and database connection are correct.

6. **Generate approved files**
   - Laravel: use Artisan for models, migrations, controllers, requests, policies, factories, seeders, and resources when appropriate.
   - CakePHP: use Bake for model/table/entity, controller, templates, tests, and `bake all` after the database tables exist.

7. **Post-generation audit**
   - Inspect relationships/associations, validation, mass assignment, authorization, routes, controllers, templates/views, redirects, empty states, and error handling.
   - For Laravel, check `$fillable`/`$guarded`, form requests, middleware, policies, route model binding, Blade `@csrf`, storage, and Eloquent relationships.
   - For CakePHP, check `initialize()`, `validationDefault()`, `buildRules()`, entity `$_accessible`, controller actions, templates, FormHelper usage, CSRF, escaping, and associations.

8. **Complete business logic**
   - Add role checks, ownership checks, status transitions, upload rules, transactions, totals, stock/order logic, notifications, or admin rules as required by the project.

9. **Complete UI and usability**
   - Laravel: finish Blade layouts, partials/components, forms, validation messages, empty states, and navigation.
   - CakePHP: finish templates/layouts/elements, baked CRUD pages, FormHelper fields, Flash messages, empty states, and navigation.

10. **Verify with framework checks**
   - Laravel checks: `php artisan migrate:status`, `php artisan route:list`, relevant tests, browser CRUD flow, auth/role checks, validation errors, logs.
   - CakePHP checks: `bin/cake migrations status`, `bin/cake routes`, `bin/cake server` or local server, browser CRUD flow, auth/role checks, validation errors, logs.

11. **Loop back on mismatch**
   - Wrong framework -> identify again.
   - Wrong ERD/database -> return to database planning.
   - Failed migration -> fix schema/migration.
   - Bad generated files -> inspect generator plan and regenerate carefully.
   - Broken routes/auth/UI -> complete/audit again.
   - Failed verification -> test, fix, and retest.

12. **Handoff clearly**
   - Report what was inspected, generated, edited, tested, not tested, and what the user must run manually.


## Framework Role For System Website Project Builder

This kit owns the implementation loop after the ERD/database is approved.

- Guide beginners through setup, database connection, migrations/imports, pilot generation, full generation, post-generation audit, and browser testing.
- For CakePHP, run or guide `bin/cake` checks, then pilot Bake one table before `bake all` on approved tables.
- For Laravel, run or guide Artisan checks, then generate resources after migration/schema planning.
- Treat Artisan/Bake output as scaffold only. Complete validation, relationships, auth, role checks, business logic, UI, routes, and verification before saying the feature is done.


---

## Aivis Agent Skills - Brain Project Builder v1.4 Rules

This skill belongs to **Aivis Agent Skills - Brain Project Builder**. The visible product name, prompt name, README name, and buyer-facing wording must use this name. Technical skill slugs may stay unchanged for compatibility.

### 1. Adaptive Beginner Mode

The AI must adjust to the user. If the user is new, explain simply, guide step by step, and ask for command output when needed. If the user is experienced, move faster and follow their requested stack, but still pause before risky actions. Do not assume the user knows Laravel, CakePHP, CakePHP Bake, Laravel Artisan, Laragon, MySQL, phpMyAdmin, migrations, routes, controllers, ORM models, or deployment.

### 2. Discuss Before Running or Changing

Before running commands or making changes, discuss the plan with the user in plain language. Read-only inspection is allowed first. Ask for confirmation before high-risk changes including creating/dropping databases, importing SQL, running migrations/seeders, running `bake all`, running large Artisan generation, overwriting files, changing authentication/roles/admin logic, deleting files, or deployment changes.

### 3. AI-Assisted Execution Mode

For tool-based AI environments such as Codex, Antigravity, and Claude Code, the AI must not force the beginner user to manually perform every technical step. If the tool can access the project, terminal, Laragon/MySQL, Composer, CakePHP, Laravel, or local server, offer to do supported actions for the user.

Use this pattern:
"I can do this for you if the tool has access, or I can guide you manually. Which do you prefer?"

Offer assisted execution for creating/checking the Laragon database, importing SQL, creating migrations, running migrations, installing Composer packages, configuring Laravel `.env`, configuring CakePHP `config/app_local.php`, running Laravel Artisan commands, running CakePHP Bake commands, checking generated files, fixing validation, relationships, templates, routes, controllers, UI, and running tests or route checks.

### 4. Public Homepage and Login Separation

Do not make the login page the homepage by default. Every system should have a public homepage unless the user confirms the system is private/internal only.

Default route flow:
`Public Homepage -> Login/Register -> Role-based Dashboard`

The public homepage should briefly show the system name, purpose, key features, available roles, and Login/Register buttons. The login page should only handle authentication. After login, redirect users based on role.

Ask if unclear:
"Should this system have a public homepage for everyone, or should the first page be login because it is an internal-only system?"

### 5. Accurate and System-Based ERD Loop

The ERD must match the real system workflow, not only simple pages. Do not create an overly basic ERD when the system has approvals, payments, uploads, reports, notifications, bookings, orders, archives, roles, attendance, audit logs, or status tracking.

Before finalizing an ERD, check for:
- user roles and permissions
- main entities and weak entities
- transactions and history tables
- approvals and status changes
- uploads/files/media
- notifications
- feedback/ratings
- reports/exports
- audit logs
- many-to-many relationships and junction tables
- foreign keys, cardinality, optional/mandatory relationships

Ask:
"Before I finalize the ERD, are there approvals, payments, uploads, reports, notifications, ratings, status tracking, audit logs, or extra roles that should be included?"

### 6. CRUD + ACRUD by Default

Every approved module must include CRUD by default: Create, Read, Update, Delete.

Also apply suitable ACRUD (Advanced CRUD) by default when useful:
- search
- filter
- sort
- pagination
- role-based access
- status update
- file/image upload
- soft delete when suitable
- export/report when suitable
- audit log for important actions

Ask before finalizing:
"I will include CRUD and useful ACRUD such as search, filter, pagination, status tracking, upload, and role-based access. Do you want extra features such as reports, notifications, export PDF, approval flow, audit logs, or dashboards?"

### 7. CakePHP Beginner Loop

For CakePHP, guide beginners safely:
1. check CakePHP/Composer setup
2. check Laragon/MySQL connection
3. check ERD, table names, primary keys, foreign keys, and relationships
4. create/import/migrate the database only after confirmation
5. Bake one simple pilot table first
6. test pilot CRUD
7. ask before baking all approved tables
8. inspect generated Table, Entity, Controller, Template, routes, validation, and associations
9. add auth, roles, business logic, UI, ACRUD, and audit logs
10. test browser flows before handoff

### 8. Laravel Beginner Loop

For Laravel, guide beginners safely:
1. check Laravel/Composer setup
2. check `.env` and database connection
3. check ERD and migration plan
4. create migrations/models/controllers with Artisan only after confirmation
5. run migrations only after confirmation
6. inspect generated models, relationships, controllers, form requests, routes, and Blade views
7. add auth, roles, business logic, UI, ACRUD, and audit logs
8. test routes and browser flows before handoff

### 9. Scaffold Output Is Not Final

CakePHP Bake and Laravel Artisan output are scaffolds only. The AI must inspect and complete generated code. Do not tell the user the system is done only because files were generated.

### 10. Clean Buyer Handoff

Keep folder structure clean. Do not create random duplicate files, unclear backup names, or scattered outputs. Put prompts, checklists, AI adapters, proof/audit files, legal files, and brand files in their correct folders.
