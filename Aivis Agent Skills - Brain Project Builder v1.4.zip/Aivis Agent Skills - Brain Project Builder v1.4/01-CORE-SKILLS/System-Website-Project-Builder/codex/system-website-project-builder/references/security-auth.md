# Security And Auth

Use this reference for authentication, roles, validation, uploads, and secrets.

## Authentication

- Store passwords with `password_hash`.
- Verify passwords with `password_verify`.
- Regenerate session IDs after login or privilege changes.
- Provide logout that clears the relevant session state.
- Do not expose whether an email, username, or account exists unless the product intentionally requires it.

## Authorization

- Check roles on the server for every protected page and state-changing endpoint.
- Keep admin, staff, customer, vendor, and guest permissions explicit.
- Do not rely on hidden buttons or client-side redirects as access control.
- For records owned by a user or business, verify ownership in the query or before the action.

## CSRF And Forms

- Require CSRF tokens for state-changing forms and endpoints that use cookie/session auth.
- Validate the HTTP method.
- Validate required fields, types, lengths, allowed values, and foreign keys.
- Preserve safe user input after validation errors.

## XSS And Output

- Escape all dynamic text in HTML.
- Escape attribute values.
- Sanitize rich text only with a deliberate allowlist if rich text is required.
- Never insert raw user content into `<script>` blocks without safe encoding.

## Uploads

- Restrict allowed file types and extensions.
- Verify MIME type where possible.
- Limit file size.
- Generate safe stored filenames.
- Store uploads outside executable paths when possible, or block script execution in upload folders.
- Delete replaced files only after the new file is safely stored and database state is updated.

## Secrets

- Keep database passwords, API keys, cookies, and hosting credentials out of skill files and committed code.
- Use environment variables or local ignored config when the project supports them.
- If the project currently uses local config files, do not broaden exposure while editing.

## Failure Modes

- Show user-safe error messages.
- Keep internal error details in logs or local debugging output.
- Fail closed for permission checks.
- Roll back partial writes when a multi-step action fails.
