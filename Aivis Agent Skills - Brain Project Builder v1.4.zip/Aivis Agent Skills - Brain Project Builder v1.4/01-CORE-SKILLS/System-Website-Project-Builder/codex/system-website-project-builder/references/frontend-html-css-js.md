# Frontend HTML, CSS, And JavaScript

Use this reference for website UI, styling, responsive behavior, and browser-side interactions.

## HTML

- Use semantic landmarks: `header`, `nav`, `main`, `section`, `article`, `aside`, and `footer`.
- Use buttons for actions and links for navigation.
- Label form fields clearly with `label` elements or accessible names.
- Keep headings hierarchical and meaningful.
- Render useful empty, loading, success, and error states.
- Escape dynamic text at render time using the project's escaping helper or the language standard.

## CSS

- Ask for theme, colors, style, typography, and references before broad styling work when those choices are not already clear.
- Preserve existing design tokens, classes, layout systems, and CSS organization.
- Use reusable classes for buttons, forms, cards, tables, alerts, nav, grids, and layout wrappers.
- Use responsive constraints such as `max-width`, `minmax`, `clamp` only where appropriate, `aspect-ratio`, and flexible grid/flex patterns.
- Keep text readable on mobile and desktop; avoid clipped text, overlapping controls, and layout shift.
- Use accessible contrast for text, buttons, form states, and alerts.
- Prefer consistent spacing, border radius, shadows, and visual hierarchy over decorative effects.

## JavaScript

- Use JavaScript to enhance server-rendered behavior, not to replace required server validation.
- Keep event listeners scoped and resilient to missing elements.
- Use `data-*` attributes for behavior hooks instead of fragile text matching.
- Debounce live search or filters when needed.
- Reflect async states: disabled buttons, loading text, success messages, and error messages.
- Handle failed `fetch` calls and invalid JSON gracefully.
- Keep cart, modal, tab, filter, and dashboard interactions keyboard-accessible where practical.

## Common UI Patterns

- Forms: show inline validation, preserve user input after errors, and make primary actions obvious.
- Tables: include search/filter/pagination when lists can grow; keep mobile fallbacks usable.
- Cards: use consistent image ratios, title lengths, action placement, and empty description handling.
- Dashboards: prioritize key metrics, recent activity, alerts, and next actions.
- Shops: make product/bundle cards scannable, keep cart totals visible, and confirm checkout outcomes clearly.

## Browser Verification

- Check desktop and mobile widths.
- Verify no horizontal overflow.
- Verify forms can be completed with keyboard and mouse.
- Verify interactive states do not depend only on hover.
- Verify dynamic UI still works after validation errors or empty results.
