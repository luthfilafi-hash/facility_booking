# Laragon Local Path Reference

Use this for PHP/MySQL projects that may run through Laragon, localhost folders, or virtual hosts.

## Required Local Setup Targets

Before final delivery, consider both common local setups:

```text
http://localhost/project-folder-name
http://project-name.test
```

If the environment cannot run both, clearly mark the missing check as `not available` and tell the user how to test it.

## Path Safety Rules

Avoid hardcoded absolute paths and links that only work in one environment.

Prefer:

- Reusable base URL helper.
- Config setting for app/base URL.
- Relative paths that work from the current page structure.
- Asset helper for CSS, JavaScript, images, uploads, and links.
- Redirect helper for PHP redirects.

Check:

- CSS paths.
- JavaScript paths.
- Image paths.
- Includes/requires.
- Form actions.
- Redirect targets.
- Admin links.
- Upload/media paths.

## Final Local Setup Instructions

Provide:

- Where to place the project folder in Laragon.
- Which URL to open for folder mode.
- Which virtual host URL to try if Laragon auto-creates one.
- How to import the database.
- Which config file to edit.
- What to test first after import.

## Common Failure Pattern

If CSS works in `http://project-name.test` but not `http://localhost/project-folder-name`, check base URL assumptions, leading slash paths, redirects, and nested page asset links.
