# Modern Deployment Targets

Use this reference when deployment is not clearly shared hosting/cPanel/phpMyAdmin.

## Detect The Target

Inspect package/build files and ask only for missing deployment intent:

- Static site: plain HTML/CSS/JS, build output, or docs site.
- Frontend app: React, Vue, Svelte, Vite, Next, Astro, or similar.
- Backend app: PHP, Node, Python, Laravel, Express, etc.
- Containerized app: Dockerfile or compose file.
- CI/CD: GitHub Actions or other pipeline config.

## Supported Targets

- GitHub Pages: static output, base path, routing, asset paths, branch/source settings.
- Vercel or Netlify: build command, output directory, env vars, redirects/rewrites, preview URL.
- Docker/VPS/cloud: image build, ports, volumes, secrets, migrations, health checks, logs, rollback.
- Git/CI: branch strategy, test/build commands, artifacts, secrets, deployment logs.
- Shared PHP hosting: cPanel, InfinityFree, phpMyAdmin, FTP/File Manager, `.htaccess`, PHP version, extensions, and database import.

## Safety Rules

- Do not invent production credentials, secrets, domains, or account settings.
- Do not replace a working deployment target without confirmation.
- Do not claim deployment success unless the production or preview URL was checked, or the missing access was clearly reported.
