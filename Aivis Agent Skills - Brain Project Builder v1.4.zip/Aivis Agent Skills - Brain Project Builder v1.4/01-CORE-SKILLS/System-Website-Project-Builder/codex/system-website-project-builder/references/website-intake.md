# Website Intake

Use this reference when starting a new website, adding a broad feature, or redesigning an interface.

## Ask Key Choices First

Ask only questions that materially change the implementation. If a detail is discoverable from the project, inspect first.

Core questions:

- What is the website's purpose and primary outcome?
- Who are the target users?
- What pages or workflows are required for the first usable version?
- What theme, colors, visual style, layout feel, typography, and reference sites or images should guide the design?
- What data/entities need to exist?
- What database tables, attributes, relationships, statuses, and ownership rules are already correct or need confirmation?
- What user roles are required?
- What deployment target should the project support?

## Design Brief

For styling or redesign work, collect:

- Theme: modern, playful, premium, minimal, corporate, luxury, youthful, academic, operational, or another direction.
- Colors: primary, secondary, accent, neutral background, and any colors to avoid.
- Layout feel: dense dashboard, spacious landing page, card grid, sidebar app, mobile-first shop, or form-first workflow.
- Typography: clean sans-serif, editorial serif, compact dashboard type, brand-specific font, or existing project typography.
- Imagery: real product photos, generated images, icons, simple illustrations, screenshots, or no imagery.
- Interaction style: static, subtle transitions, animated hero, live search, filters, modals, tabs, cart drawer, or dashboard widgets.

## Product Brief

For new functionality, collect:

- User journeys and success states.
- Required roles and permissions.
- Data fields and relationships.
- Existing tables/attributes to use, or new schema changes to confirm before coding.
- Empty states, validation rules, and error states.
- Admin or staff operations needed to manage the feature.
- Reporting, export, approval, notification, or audit needs.

## Defaults When The User Leaves Details Open

- Build the first usable screen or workflow, not a generic marketing page.
- Choose a restrained, responsive, accessible design.
- Use PHP/MySQL-first conventions for new projects.
- Use plain HTML/CSS/JavaScript unless the project already uses a framework.
- Include practical admin management when data is created by users or customers.
