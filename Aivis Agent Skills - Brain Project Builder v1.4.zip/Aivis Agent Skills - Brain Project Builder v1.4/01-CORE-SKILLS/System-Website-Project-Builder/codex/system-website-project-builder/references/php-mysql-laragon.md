# PHP, MySQL, And Laragon

Use this reference for PHP/MySQL-first projects and Laragon-style local development.

## PHP Project Conventions

- Reuse existing config, session, auth, database, URL, upload, and layout helpers.
- Keep includes and shared functions in the project's established locations.
- Keep page-level PHP, HTML, CSS, and JavaScript organization consistent with nearby files.
- Prefer small, readable server handlers over broad rewrites.
- Use `require_once` or the project's autoload pattern consistently.

## Database Access

- Inspect the database schema before coding database-backed features.
- Ask the user to confirm unclear tables, columns/attributes, relationships, status values, roles, and ownership rules.
- Do not invent schema details when SQL dumps, migrations, or existing queries are missing or ambiguous.
- Prefer PDO or the project's existing database wrapper.
- Use prepared statements for all user-controlled values.
- Keep read queries and count queries aligned for filtered lists and pagination.
- Use transactions for multi-step writes that must succeed or fail together.
- Handle missing rows, duplicate rows, and permission mismatches gracefully.

## Schema Changes

- Inspect current schema, SQL dumps, migrations, and seed data before changing tables.
- Ask for approval before adding tables, columns, foreign keys, statuses, or ownership rules.
- Choose additive changes when possible.
- Add indexes for foreign keys, search fields, status filters, and date filters used frequently.
- Keep application code and schema changes synchronized.
- Update the maintained SQL dump or migration record if the project expects it.

## Laragon Workflow

- Discover the PHP binary and MySQL tools if they are not on `PATH`.
- Run PHP syntax checks on changed PHP files.
- Use local database checks to confirm schema assumptions before and after migrations.
- Regenerate dumps only after the local database is correct and verified.
- Do not bake machine-specific paths into reusable project code.

## PHP Safety Defaults

- Use `password_hash` and `password_verify` for passwords.
- Use `htmlspecialchars` with `ENT_QUOTES` and `UTF-8` for dynamic text in HTML.
- Validate request method and required fields before writes.
- Redirect after successful POSTs when the page is not an API endpoint.
- Return consistent JSON shapes from API endpoints.
- Log server-side details where appropriate, but show user-safe messages.
