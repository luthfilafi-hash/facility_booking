# Admin And Business Apps

Use this reference for dashboards, management systems, CRUD workflows, reports, approvals, and role-based tools.

## Common Areas

- Dashboard with key metrics, recent activity, alerts, and shortcuts.
- CRUD management for core records.
- Role-based navigation.
- Search, filters, sort, and pagination for growing lists.
- Detail pages for records with history or related data.
- Approval/rejection workflows when user submissions need review.
- Reports, exports, and date filters when managers need summaries.

## Dashboard Guidance

- Prioritize actions and information the user needs today.
- Use compact metric cards, recent lists, status groups, and alerts.
- Link metrics to the filtered list they summarize.
- Avoid decorative dashboard widgets that do not support decisions.

## CRUD Guidance

- Validate on the server.
- Show clear create/edit/delete or enable/disable actions.
- Confirm destructive actions.
- Prefer soft delete, archive, inactive status, or restore when records are business-critical.
- Keep list counts, filters, and pagination based on the same server-side result set.

## Roles And Permissions

- Define what each role can view, create, edit, approve, delete, export, and configure.
- Keep navigation consistent with permissions, but enforce permissions on the server too.
- Test direct URL access to protected pages.

## Reports

- Make filters explicit.
- Use date ranges and status filters consistently.
- Keep totals aligned with visible filters.
- Include export only when the project needs it and data exposure is acceptable.

## UI Patterns

- Dense operational screens should be scannable and stable.
- Tables need readable columns, empty states, and mobile behavior.
- Forms need grouped fields, required markers, validation messages, and save/cancel behavior.
- Approval screens should show enough context to make a decision without opening many tabs.
