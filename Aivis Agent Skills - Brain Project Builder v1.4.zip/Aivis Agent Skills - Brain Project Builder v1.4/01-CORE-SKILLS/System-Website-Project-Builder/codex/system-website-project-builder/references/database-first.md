# Database First Reference

Use this reference before database-backed coding.

## Core Rule

Follow the user's actual database for existing, client-safe, production, or graded work. If the database is unclear and the task depends on it, ask the user to confirm before final implementation.

In `Prototype Mode`, the agent may propose a practical database design, but every unconfirmed table, column, relationship, status, role, and rule must be labeled `proposed`.

Do not pretend proposed database design is confirmed database truth.

## Inspect Before Coding

Check available project truth:

- Database config files.
- Connection and query helpers.
- SQL dumps.
- Migration files.
- Seed files.
- Model/entity files.
- Existing queries in PHP, API routes, controllers, and admin pages.
- Forms that create or update related records.
- XML, XSD, XSLT, JSON, CSV, static HTML, or old data files when converting legacy projects.

## Prototype Defaults

For MVP or prototype work, the agent may suggest common defaults such as:

- `id` primary keys.
- `created_at` and `updated_at` timestamps.
- `status` fields.
- `role` fields.
- Common foreign keys such as `user_id`, `product_id`, or `order_id`.
- Standard role/status examples when they fit the user's stated goal.

These are proposals until approved. Mark them as `proposed`.

## Ask When Unclear

Ask the user to confirm when unclear information affects implementation:

- Database name.
- Table names and purposes.
- Column or attribute names.
- Required, optional, nullable, and unique fields.
- Primary keys, foreign keys, and relationships.
- Allowed status values.
- User roles and permissions.
- Record ownership rules.
- Delete/archive/disable behavior.
- Whether a database already exists or must be created.
- Whether SQL dumps or migrations should be updated.

## High-Risk Stop Conditions

Pause before coding when:

- Existing code and schema disagree.
- A production/client feature requires a new table or column that the user has not approved.
- Status values, role names, ownership rules, or payment/order/stock logic are unclear.
- Checkout, payment, auth, permissions, inventory, admin approval, or destructive data behavior would change.
- Credential, password hash, seed account, or live account SQL would be created.

## Confirmation Sheet Template

For high-risk or final schema work, use a compact table or list containing:

```text
Database name:

Table:
Purpose:
Columns:
Primary key:
Foreign keys:
Nullable fields:
Unique fields:
Enum/status values:
Relationships:
Source:
Original fields:
Proposed fields:
Needs approval:
```

## Ready To Code

Proceed when the task's risk level allows it:

- Low-risk UI or copy work does not need database confirmation.
- Prototype work may proceed with labeled proposals.
- Existing/client-safe database work needs discovered or confirmed tables, relationships, role rules, ownership rules, and schema update expectations.

## Final Report

For database-backed work, report:

- Tables used.
- Columns/attributes used.
- Proposed versus confirmed schema decisions.
- Schema changes made or proposed.
- SQL dump/migration updates made or skipped.
- Database checks run.
- Remaining database assumptions.
