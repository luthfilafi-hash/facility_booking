# Risk Gates

Use risk gates to avoid both reckless changes and unnecessary waiting.

## Low Risk

Examples:

- Copy edits.
- Small CSS changes.
- Minor layout spacing.
- Asset swaps.
- UI-only bug fixes.
- Non-sensitive documentation changes.

Behavior: inspect affected files, proceed, and report relevant checks.

## Medium Risk

Examples:

- New non-production features.
- New reusable components.
- Reversible folder or config organization.
- Prototype schema suggestions.
- Local-only workflow changes.

Behavior: proceed with labeled assumptions when reasonable. Ask a compact question only when ambiguity materially changes the output.

## High Risk

Examples:

- Auth, admin permissions, roles, sessions, or access control.
- Payment, checkout, orders, stock, inventory, or money logic.
- Uploads and file execution paths.
- Production deployment, DNS, live accounts, secrets, credentials, or password hashes.
- Destructive database changes.
- Final production schema, migrations, SQL dumps, or seed users.
- Major UI replacement, project architecture migration, or full reset.

Behavior: pause and ask for confirmation before implementation.
