# Scope-Aware Verification

Match the final report to the task size.

## Simple UI Or Copy Change

Report:

- Files changed.
- CSS/visual check.
- Browser or responsive check when available.
- Anything not checked and why.

Do not include database, deployment, checkout, stock, or admin rows unless affected.

## Database-Backed Change

Report:

- Tables and columns used.
- Proposed versus confirmed schema.
- SQL dump or migration status.
- MySQL/database check status.
- Validation and error-path checks.

## Auth, Admin, Shop, Upload, Or Payment Change

Report:

- Allowed and denied access checks.
- CSRF/session/validation checks where relevant.
- Order, stock, checkout, payment, upload, or admin behavior checks where relevant.
- Direct URL or ownership checks where relevant.

## Deployment Or Final Package

Use the full verification matrix. Include local setup, production/deployment target, environment variables/secrets status, changed-file upload list, rollback notes, and checks that could not run.
