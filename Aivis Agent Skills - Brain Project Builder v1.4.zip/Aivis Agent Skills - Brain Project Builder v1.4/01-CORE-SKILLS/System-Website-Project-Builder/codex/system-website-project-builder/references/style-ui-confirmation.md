# Style And UI Confirmation Reference

Use this before coding UI, page templates, CSS, JavaScript interactions, or visual redesigns.

## Required Question For Major UI Work

For redesigns, new themes, page templates, large CSS changes, or replacing old layout, ask:

```text
Do you want to keep the old design or redesign it?
```

For low-risk maintenance such as changing a button color, fixing spacing, replacing a small asset, or updating copy, inspect the existing style and proceed if the request is clear.

Do not begin broad UI conversion until the keep/redesign choice is answered or clearly implied by the user.

## Confirm These Choices

- Keep old design, partial refresh, or full redesign.
- Color direction.
- Typography/font direction.
- Layout direction.
- Product/card/list/table style.
- Admin dashboard style.
- Whether existing CSS should be preserved.
- Whether existing image assets should be reused.
- Whether the new project should visually match the old version exactly.

## If User Wants Same Design

Preserve as much as possible:

- Original CSS files and classes.
- Layout structure.
- Colors and spacing.
- Images and icons.
- Page visual identity.
- Existing interaction behavior.

Only add helper CSS when necessary, and explain why it was added.

## If User Wants Redesign

Ask for theme, colors, style, typography, layout feel, and references before coding.

Keep backend behavior safe while changing UI.

## Verification

Before saying UI is done, check:

- CSS loads on all relevant pages.
- JavaScript loads and runs where needed.
- Images load.
- Navigation and forms still work.
- Layout works on desktop and mobile.
- Important old visual identity is preserved if requested.
