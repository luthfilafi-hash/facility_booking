# Kit Orchestration

Use one primary kit and optional supporting kit rules. Do not force tasks into one silo when real work crosses boundaries.

## Primary Kit Selection

- System Website Project Builder: full-stack build, conversion, maintenance, or bug fixing.
- Architecture Designer: database, ERD, file structure, feature boundaries, and planning-only tasks.
- UI Component Builder: frontend components, styling, responsive UI, visual matching, and safe JavaScript UI behavior.
- QA Security Auditor: read-only QA/security review.
- Deployment Admin: deployment, hosting, production config, CI/CD, release package, and rollback work.

## Supporting Rules

Examples:

- Dashboard build: System Website Project Builder primary, Architecture Designer for data shape, UI Component Builder for component polish.
- Security fix: System Website Project Builder primary, QA Security Auditor for checks.
- Release preparation: Deployment Admin primary, System Website Project Builder for PHP/database path checks.

State the primary kit and supporting kit rules in the status block for non-trivial tasks.
