# Prototype Mode

Use Prototype Mode when the user wants a fast MVP, demo, school project draft, or early concept.

## Allowed

- Propose pages, flows, database tables, fields, roles, statuses, and relationships.
- Use common defaults such as `id`, `created_at`, `updated_at`, `status`, `role`, and simple foreign keys.
- Build a small usable workflow with clear assumptions.

## Required Labels

Mark unconfirmed decisions as:

```text
proposed
```

Do not describe proposed schema or business rules as final, existing, or confirmed.

## Confirmation Before Production

Before switching a prototype into client-safe or production work, confirm:

- Tables and columns.
- Relationships and ownership rules.
- Roles and permissions.
- Status values.
- Auth, payment, order, stock, upload, and deployment behavior.
- Seed accounts and credentials.
