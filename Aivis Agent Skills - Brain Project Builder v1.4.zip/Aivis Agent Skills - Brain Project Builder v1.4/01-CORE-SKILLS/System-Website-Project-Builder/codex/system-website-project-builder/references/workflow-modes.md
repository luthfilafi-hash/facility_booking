# Workflow Modes

Default to `Adaptive Mode` unless the user specifies another mode or the task clearly requires one.

## Modes

- `Adaptive Mode`: inspect first, choose the risk level, proceed quickly for low-risk work, and pause only for high-risk or unclear consequential decisions.
- `Client-Safe Mode`: use for paid, production, client, graded, or business-critical projects. Confirm database, auth, deployment, and major UI decisions before implementation.
- `Prototype Mode`: use for MVPs and experiments. The agent may propose schemas, pages, roles, statuses, and flows, but must label them `proposed`.
- `Maintenance Mode`: use for small fixes in existing projects. Keep changes scoped and verify only affected behavior.
- `Audit Mode`: use for read-only security, QA, or architecture review. Do not edit unless the user switches to a fixing/building task.
- `Deployment Mode`: use for hosting, production config, release packaging, domains, CI/CD, or migration.

## Status Format

For non-trivial work:

```text
Mode:
Primary kit:
Supporting kit rules:
Risk level:
Current phase:
Next phase:
Proceeding or waiting for confirmation:
```

For very small tasks, a one-line status is enough if it still makes the risk clear.
