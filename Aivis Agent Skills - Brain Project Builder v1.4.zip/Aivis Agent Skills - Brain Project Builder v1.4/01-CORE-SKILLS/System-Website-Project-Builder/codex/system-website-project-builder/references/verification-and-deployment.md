# Verification And Deployment

Use this reference before reporting work complete or preparing a website for release.

## Local Verification

- Run syntax checks for changed PHP files when PHP is available.
- Run available tests, linters, type checks, or build checks when the project has them.
- Open changed pages in a browser when UI is affected and a browser/server is available.
- Check CSS, JavaScript, image, link, form action, redirect, include, and admin page paths when relevant.
- For Laragon/PHP projects, check or mark both `http://localhost/project-folder-name` and `http://project-name.test`.
- Test the main happy path and at least one validation/error path for feature work.
- Check mobile and desktop layouts for meaningful UI changes.
- Check browser console and network errors for JavaScript changes.

## Database Verification

- Confirm tables and columns used by code exist.
- Separate proposed schema from confirmed schema.
- Confirm migrations or SQL dumps reflect intended schema changes when schema changed.
- Check foreign keys, indexes, statuses, and required seed data when relevant.
- Verify counts, filters, and pagination use the same server-side criteria.
- Clean up test data when it should not remain.

## Auth And Role Verification

- Test allowed and denied access for each affected role.
- Test direct URL access to protected pages.
- Test state-changing actions without valid CSRF tokens if practical.
- Confirm users cannot update records they do not own or manage.

## Shared Hosting And cPanel Deployment

- Treat hosting as deployment, not development.
- Upload only changed files when practical.
- Import SQL through phpMyAdmin or the host's supported database tool when schema/data changes are intended.
- Keep local and hosted configuration differences isolated.
- Verify file paths, case sensitivity, PHP version, extensions, upload limits, and `.htaccess` behavior.
- Avoid full site replacement unless the user explicitly intends a full reset.

## Modern Deployment

Detect the target before giving instructions:

- Static sites: GitHub Pages, Netlify, Vercel static output, or similar.
- Node/frontend apps: build command, output directory, environment variables, routing fallback, and preview deployment.
- Docker/VPS/cloud: Dockerfile, compose file, exposed ports, persistent storage, secrets, migrations, health checks, and rollback.
- Git/CI deployment: branch, build command, test command, artifacts, secrets, and deployment logs.

Do not force cPanel/phpMyAdmin steps onto projects that use a modern static, Git, container, or cloud workflow.

## Deployment Checklist

- List changed files.
- List database changes or confirm none.
- List database tables/attributes used and any assumptions that remain.
- Confirm config/secrets are not overwritten.
- Confirm uploads/media folders are preserved when relevant.
- Smoke test public pages, login, admin pages, forms, and changed workflows after upload/deploy when access is available.
- If an HTTP 500, blank page, broken route, failed build, or deployment error appears, check PHP errors, mixed old/new files, schema mismatch, missing extensions, path/case differences, build logs, env vars, and routing config.

## Final Report

- Summarize what changed.
- Mention verification performed.
- Mention anything not tested and why.
- Include deployment notes only when deployment was part of the task.
- Use a scoped verification summary for small changes.
- Use the full matrix for release, deployment, full build, or final ZIP/package delivery.
