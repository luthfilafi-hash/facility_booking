# Project Discovery

Use this reference before changing an unknown or existing website project.

## First Pass

- Identify the stack from files and folders: PHP pages, framework config, package manifests, composer files, SQL dumps, public assets, server config, and docs.
- Find entrypoints such as `index.php`, route files, controllers, admin folders, API folders, public asset folders, and includes/shared helpers.
- Find database configuration, connection helpers, query wrappers, schema files, seed data, migration scripts, and SQL dumps.
- For database-backed work, list the relevant tables, columns/attributes, relationships, statuses, roles, and ownership rules found in the project.
- Find auth/session helpers, middleware, role checks, CSRF helpers, validation helpers, upload helpers, and layout/header/footer files.
- Find frontend organization: global CSS, page-local CSS, JavaScript files, component folders, templates, and icon/image assets.

## Useful Search Targets

- Config: `DB_`, `database`, `mysqli`, `PDO`, `host`, `username`, `password`.
- Auth: `session_start`, `password_hash`, `password_verify`, `csrf`, `require_login`, `role`, `middleware`.
- Data writes: `INSERT`, `UPDATE`, `DELETE`, `move_uploaded_file`, `fetch`, `XMLHttpRequest`.
- UI reuse: `header`, `footer`, `layout`, `navbar`, `sidebar`, `card`, `modal`, `toast`.
- Deployment: `.htaccess`, `public_html`, `htdocs`, `config.php`, `env`, `sql`, `dump`.

## Decision Rules

- If project conventions are clear, follow them.
- If multiple patterns exist, prefer the newest or most widely used pattern in the project.
- If a helper already handles URLs, uploads, auth, escaping, pagination, or database access, use it instead of duplicating logic.
- If a feature spans frontend and backend, trace the full request path before editing.
- If a schema change is needed, find how this project records schema changes before applying one.
- If database tables, attributes, statuses, or relationships are unclear, ask the user to confirm them before coding.

## Before Editing

- State the files or subsystems affected.
- Preserve unrelated user changes.
- Keep the change narrow unless the user requested a new build or redesign.
- For broad new work, ask the key product/design choices from `website-intake.md` first.
- For database-backed work, use `database-first.md` before editing code.
