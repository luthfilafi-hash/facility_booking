# Ecommerce And Bundle Shops

Use this reference for shop websites, bundle stores, carts, checkout, orders, and inventory.

## Core Entities

Common entities include:

- Products with name, description, price, image, category, status, and stock.
- Bundles with name, description, bundle price, included products, quantities, status, and image.
- Customers or users.
- Cart items.
- Orders and order items.
- Payments or payment intent records.
- Admin users or staff roles.

Adapt these entities to the project instead of forcing this exact shape.

## Customer Flow

- Browse products and bundles.
- Search, filter, and view details.
- Add items to cart.
- Update quantities and remove items.
- Review totals before checkout.
- Enter required customer, delivery, or pickup information.
- Place order and receive a clear confirmation.
- View order status when accounts exist.

## Admin Flow

- Manage products, bundles, categories, stock, prices, and images.
- View orders by status and date.
- Update order status.
- See low-stock or unavailable products.
- Review customer/order details safely.
- Avoid destructive deletes when archiving or disabling is safer.

## Cart And Pricing

- Calculate totals on the server.
- Do not trust client-submitted prices.
- Store order item names and prices at purchase time if historical accuracy matters.
- Validate stock and bundle availability at checkout.
- Use transactions for checkout writes and stock changes.
- Handle empty cart, invalid quantity, inactive product, and changed price states.

## Payment Readiness

- Separate order creation from payment confirmation when real payments are involved.
- Store payment status clearly.
- Do not mark paid orders from client-only signals.
- Keep test payment instructions separate from production credentials.

## UI Guidance

- Product and bundle cards should show image, name, price, key contents or benefits, status, and primary action.
- Cart summaries should keep subtotal, discounts, fees, and total easy to scan.
- Checkout should reduce distractions and show validation clearly.
- Admin order screens should prioritize status, customer, time, total, and next action.
