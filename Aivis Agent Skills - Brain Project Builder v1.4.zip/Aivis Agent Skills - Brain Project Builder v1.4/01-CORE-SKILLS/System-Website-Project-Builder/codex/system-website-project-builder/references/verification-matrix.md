# Verification Matrix Reference

Use this full matrix only for full builds, releases, deployments, final ZIP/package delivery, or broad PHP/MySQL website handoff.

For small changes, use [scope-aware-verification.md](scope-aware-verification.md) and report only relevant checks.

## Full Matrix

Report checks as `yes`, `no`, or `not available`.

```text
PHP syntax checked:
MySQL tested:
Database import order checked:
Database connection file checked:
CSS path checked:
JavaScript path checked:
Images checked:
Links/navigation checked:
Forms checked:
Redirects checked:
Login/signup flow checked:
Admin detection/access checked:
Checkout login requirement checked:
Order saving logic checked:
Stock update logic checked:
Contact form saving checked:
localhost/project-folder checked:
Laragon virtual host checked:
Modern deployment target checked:
Final ZIP generated:
```

Only write `yes` when the check was actually performed.

## If Checks Cannot Run

If PHP server, MySQL, browser, Laragon, CI, or hosting access is unavailable, say so plainly.

Give the user exact manual checks to perform for the relevant target, such as:

- Import SQL file order.
- Update database config.
- Open `http://localhost/project-folder-name`.
- Open `http://project-name.test` when available.
- Confirm CSS, JavaScript, images, login/admin pages, and key workflows.
- For modern deployment, confirm build output, environment variables, routing fallback, production URL, and deployment logs.

## Final ZIP Rule

Do not generate or claim a final ZIP/package is ready until relevant CSS, JavaScript, images, links, redirects, database files, local path behavior, and deployment path behavior are checked or explicitly marked `not available`.
