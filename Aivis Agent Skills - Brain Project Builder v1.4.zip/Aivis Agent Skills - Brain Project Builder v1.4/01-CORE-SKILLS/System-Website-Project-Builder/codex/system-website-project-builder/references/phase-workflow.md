# Phase Workflow Reference

Use this reference for full website builds, conversions, PHP/MySQL student systems, high-risk work, and tasks that touch database, UI, auth, checkout, orders, stock, payment, uploads, or deployment.

## Adaptive Status Format

For non-trivial work, show:

```text
Mode:
Primary kit:
Supporting kit rules:
Risk level:
Current phase:
Next phase:
Proceeding or waiting for confirmation:
```

## Full Phase Order

Use the full order for builds, conversions, high-risk changes, and final delivery:

1. Project Inspection
2. Source Structure Analysis
3. Database Planning
4. Database Confirmation
5. Style/UI Confirmation
6. Project Structure Recommendation
7. Coding / Conversion
8. Local Setup Instructions
9. Verification / Testing
10. Final Delivery Summary

## Short Maintenance Flow

For low-risk changes such as copy edits, small CSS changes, minor UI polish, asset swaps, or scoped bug fixes:

1. Inspect the affected files.
2. State the risk level and relevant assumptions.
3. Implement the scoped change.
4. Run relevant checks only.
5. Summarize what changed and what was verified.

## Confirmation Gates

Pause and ask for confirmation before high-risk changes:

- Final production schema, migrations, SQL dumps, seed data, or destructive database work.
- Auth, admin permissions, checkout, orders, stock, payment, uploads, secrets, live accounts, or deployment behavior.
- Replacing old CSS, layout, classes, images, page behavior, project architecture, or deployment target.

For medium-risk work, ask only when ambiguity would materially change the result. Otherwise proceed with clearly labeled assumptions.

## Source Truth Rules

Treat existing XML, XSD, XSLT, JSON, CSV, static HTML, SQL, config, and old data files as source truth until the user approves conversion.

When a field or behavior is inferred but not confirmed, mark it as:

```text
proposed
```

or:

```text
suggested but unconfirmed
```

Do not present proposed behavior as confirmed system truth.
