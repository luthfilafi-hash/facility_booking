# Codex Installation

Use this folder when installing Aivis Agent Skills - Brain Project Builder v1.4 into Codex.

## Install

Copy the `system-website-project-builder` folder into the Codex skills directory used by the buyer's machine or workspace.

Common destination:

```text
%USERPROFILE%\.codex\skills\system-website-project-builder
```

## Use

Start a Codex task with:

```text
Use $system-website-project-builder.
Inspect this project first.
Tell me the mode, primary kit, supporting kit rules, risk level, current phase, next phase, and whether you can proceed or need confirmation.
```

## Expected Behavior

Codex should:

- Inspect before coding.
- Use Adaptive Mode by default.
- Use low, medium, and high risk gates.
- Proceed quickly for low-risk tasks.
- Pause for high-risk client/production changes.
- Allow prototype proposals when labeled `proposed`.
- Use scope-aware verification instead of a full matrix for every task.
