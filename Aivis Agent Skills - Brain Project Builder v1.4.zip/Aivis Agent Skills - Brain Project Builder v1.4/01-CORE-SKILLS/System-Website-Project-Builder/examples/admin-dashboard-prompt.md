# Demo Prompt: Admin Dashboard

Use this prompt to demonstrate a mixed full-stack/UI/data workflow.

```text
Use Aivis Agent Skills - Brain Project Builder v1.4.
Create or improve an admin dashboard.

Use System Website Project Builder as the primary kit, Architecture Designer for data shape, and UI Component Builder for dashboard UI.

Inspect the current routes/pages, database/config setup, auth and roles, CSS/JS, and available data/entities.
Show mode, primary kit, supporting kit rules, risk level, current phase, next phase, and whether you can proceed or need confirmation.

Ask compact questions for dashboard metrics, CRUD sections, filters, reports, approvals, roles, and actions.
Pause before changing roles, permissions, destructive actions, production database schema, or admin access behavior.
```

## Good Agent Behavior

- Combines data planning and UI rules.
- Uses real project data instead of fake hardcoded cards when possible.
- Treats admin permissions as high risk.
- Uses scope-aware verification instead of always printing a full matrix.
