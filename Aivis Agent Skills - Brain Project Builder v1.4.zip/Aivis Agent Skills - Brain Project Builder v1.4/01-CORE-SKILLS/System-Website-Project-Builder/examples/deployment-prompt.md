# Demo Prompt: Deployment Prep

Use this prompt to demonstrate target-aware deployment.

```text
Use Aivis Agent Skills - Brain Project Builder v1.4 with Deployment Admin as supporting rules.
Prepare this project for deployment.

Inspect config, database connection setup, SQL dumps/migrations, public assets, uploads/media folders, .htaccess, package/build files, Docker files, CI/CD files, and environment-specific paths.

Detect whether this should deploy to shared hosting/cPanel/InfinityFree/phpMyAdmin, GitHub Pages, Vercel, Netlify, Docker, GitHub Actions, Git deployment, or another target.

Show mode, primary kit, supporting kit rules, risk level, current phase, next phase, and whether you can proceed or need confirmation.

Ask before production deployment, secrets, DNS, database import, credential SQL, full replacement upload, or rollback-affecting changes.
Return target-specific deployment steps and verification checks.
```

## Good Agent Behavior

- Detects target before giving steps.
- Does not force cPanel/phpMyAdmin onto modern projects.
- Protects production config and secrets.
- Uses target-specific verification.
