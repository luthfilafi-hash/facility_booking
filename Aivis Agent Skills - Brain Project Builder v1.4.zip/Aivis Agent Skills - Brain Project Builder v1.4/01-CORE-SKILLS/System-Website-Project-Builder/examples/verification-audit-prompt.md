# Demo Prompt: Verification Audit

Use this prompt when a buyer wants the AI to review whether a task is actually finished.

```text
Use Aivis Agent Skills - Brain Project Builder v1.4 verification rules.
Review the recent changes in this project.

Show mode, primary kit, supporting kit rules, risk level, current phase, next phase, and whether you can proceed or need confirmation.

Use scope-aware verification:
- For small UI/copy changes, report relevant UI checks only.
- For database work, report table/column/schema/query checks.
- For auth/admin/shop/upload/payment work, report relevant flow checks.
- For deployment, release, or final ZIP/package work, use the full matrix.

Do not claim a check passed unless you actually ran it or can point to evidence.
```

## Good Agent Behavior

- Reads changed files before judging.
- Separates verified facts from assumptions.
- Avoids bloated reports for small tasks.
- Calls out missing checks clearly.
