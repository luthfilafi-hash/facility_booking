# CakePHP Bake Project Prompt

```text
Use Aivis Agent Skills - Brain Project Builder v1.4.
Framework override: CakePHP.
Use CakePHP conventions and Bake.

Workflow:
1. Inspect the existing CakePHP project first.
2. Identify CakePHP/PHP/Composer versions and current folder structure.
3. Inspect `src/Controller`, `src/Model/Table`, `src/Model/Entity`, `templates`, `config/routes.php`, migrations, auth, and database config.
4. Confirm or design the database/migrations before baking files.
5. Use `bin/cake bake` only after tables/migrations are clear.
6. Inspect Bake output after generation.
7. Complete validation, ORM associations, controllers, templates, auth/role checks, CSRF, escaping, redirects, empty states, and error handling.
8. Verify migrations, routes, CRUD flow, auth access, and UI.

Do not treat `bin/cake bake all` output as complete until it is reviewed and connected properly.
```


## Beginner-safe CakePHP flow

Assume the user may not know CakePHP.
Explain each phase before running commands.

Flow:
1. Check CakePHP app/environment.
2. Check ERD and database table shape.
3. Create/apply migrations or import SQL.
4. Run one pilot Bake first.
5. Bake all approved tables.
6. Audit generated files.
7. Add real auth, roles, validation, associations, business logic, UI, and security.
8. Test CRUD and routes.

After `bin/cake bake all`, continue with post-Bake completion. Do not stop at generated files.
