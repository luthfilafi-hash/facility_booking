# Laravel Artisan Project Prompt

```text
Use Aivis Agent Skills - Brain Project Builder v1.4.
Framework override: Laravel.
Use Laravel conventions and Artisan commands.

Workflow:
1. Inspect the existing Laravel project first.
2. Identify Laravel/PHP/Composer versions and current folder structure.
3. Inspect routes, controllers, models, migrations, seeders, factories, Blade views, auth, middleware, and `.env.example`.
4. Confirm or design the database/migrations before generating files.
5. Use Artisan generation only after the schema/risk gate is clear.
6. Inspect generated files after Artisan runs.
7. Complete validation, Eloquent relationships, controllers, Blade UI, auth/role checks, CSRF, redirects, empty states, and error handling.
8. Verify migrations, routes, CRUD flow, auth access, and UI.

Do not treat Artisan-generated files as complete until they are reviewed and connected properly.
```
