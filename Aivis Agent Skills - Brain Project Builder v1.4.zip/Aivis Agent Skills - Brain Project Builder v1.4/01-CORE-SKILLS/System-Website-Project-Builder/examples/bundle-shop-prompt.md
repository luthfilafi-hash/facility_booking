# Demo Prompt: Bundle Shop Website

Use this prompt to demonstrate v1.4 on a new or empty PHP/MySQL project.

```text
Use Aivis Agent Skills - Brain Project Builder v1.4.
Build a PHP/MySQL bundle shop website.

Use System Website Project Builder as the primary kit, Architecture Designer for data planning, UI Component Builder for shop UI, and Deployment Admin only for deployment notes.

First inspect the project structure. If this is new/empty, say so.
Show mode, primary kit, supporting kit rules, risk level, current phase, next phase, and whether you can proceed or need confirmation.

If no database exists, propose an MVP schema for products, bundles, cart, orders, order items, users, and admin roles. Label proposed fields and statuses as proposed.

Pause before final production schema, checkout, payment, order saving, stock updates, live credentials, or deployment.

Build the first usable version only after the required risk-level confirmations.
```

## Good Agent Behavior

- Uses multiple kit rules without becoming siloed.
- Proposes MVP schema when appropriate and labels it `proposed`.
- Pauses for high-risk checkout/payment/order/stock decisions.
- Calculates prices and totals on the server.
- Does not trust client-submitted prices.
- Verifies only relevant checks until final release.
