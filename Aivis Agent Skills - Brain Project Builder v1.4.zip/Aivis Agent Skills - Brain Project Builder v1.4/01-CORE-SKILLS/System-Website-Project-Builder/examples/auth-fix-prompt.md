# Demo Prompt: Login, Register, And Roles

Use this prompt to demonstrate high-risk auth work.

```text
Use Aivis Agent Skills - Brain Project Builder v1.4 in Client-Safe Mode.
Inspect and fix the auth flow.

Show mode, primary kit, supporting kit rules, risk level, current phase, next phase, and whether you can proceed or need confirmation.

Inspect login, registration, logout, sessions, password hashing, roles, protected pages, redirects, and database logic before editing.

Pause before changing roles, admin access, login redirects, registration behavior, user tables, status values, ownership rules, or seed accounts.

Fix confirmed issues with prepared statements, password_hash/password_verify, session_regenerate_id, server-side role checks, CSRF where relevant, output escaping, validation, and safe redirects.
Verify allowed and denied access paths before reporting done.
```

## Good Agent Behavior

- Treats auth as high risk.
- Confirms role/database behavior before changing it.
- Does not trust frontend-submitted roles.
- Reports actual checks performed.
