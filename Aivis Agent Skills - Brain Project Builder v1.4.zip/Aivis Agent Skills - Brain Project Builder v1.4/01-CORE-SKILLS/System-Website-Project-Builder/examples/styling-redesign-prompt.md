# Demo Prompt: Styling Redesign

Use this prompt to show major UI work.

```text
Use Aivis Agent Skills - Brain Project Builder v1.4.
Redesign this website's interface.

Inspect existing HTML, CSS, JavaScript, layouts, shared headers/footers, assets, and page patterns.
Show mode, primary kit, supporting kit rules, risk level, current phase, next phase, and whether you can proceed or need confirmation.

Before editing, ask whether to keep the old design, partially refresh, or fully redesign.
Confirm theme, colors, visual style, layout feel, typography, reference websites/images, image reuse, and pages that matter most.

After confirmation, improve styling while preserving working backend behavior.
Use focused UI verification unless this becomes a full release.
```

## Good Agent Behavior

- Asks before major redesign.
- Preserves backend behavior and form actions.
- Uses responsive CSS and accessible contrast.
- Avoids full verification matrix unless the task scope requires it.
