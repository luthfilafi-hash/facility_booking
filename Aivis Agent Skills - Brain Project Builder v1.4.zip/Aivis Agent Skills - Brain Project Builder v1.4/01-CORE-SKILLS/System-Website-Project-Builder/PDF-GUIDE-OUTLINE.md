# PDF Guide Outline

Use this outline to create a polished PDF guide later. Add screenshots or video links after testing the kit.

## Cover Page

- Title: System Website Project Builder core skill
- Version: `v1.4`
- Subtitle: Portable adaptive AI instructions for website projects
- Owner/author name
- Date

Screenshot slot:

```text
[Insert product cover image or clean desktop screenshot]
```

## 1. What This Kit Does

Explain that the kit helps AI coding agents:

- Inspect projects before coding.
- Choose a workflow mode.
- Use risk gates instead of pausing for everything.
- Ask better project and design questions.
- Follow the user's actual database for existing/client-safe work.
- Propose schemas and flows in Prototype Mode when labeled `proposed`.
- Build frontend, backend, database, auth, admin, ecommerce, and deployment workflows.
- Verify work according to task scope.

Video suggestion:

```text
[Optional video: 2-minute overview of v1.4 modes and folder structure]
```

## 2. Workflow Modes

Explain:

- Adaptive Mode: recommended default.
- Client-Safe Mode: paid, production, client, graded, or business-critical work.
- Prototype Mode: fast MVPs with proposed schema/flows.
- Maintenance Mode: small fixes.
- Audit Mode: read-only review.
- Deployment Mode: hosting and release work.

Screenshot slot:

```text
[Screenshot: AI response showing Mode, Primary kit, Risk level, Current phase]
```

## 3. Risk Gates

Explain:

- Low risk: inspect and proceed.
- Medium risk: proceed with assumptions or ask compact confirmation.
- High risk: pause and confirm.

Include examples:

- Button color change: low risk.
- Prototype student system schema: medium risk.
- Login roles or payment flow: high risk.

## 4. Choose Your AI Tool

Include one section per adapter:

- Codex
- Claude Code
- Antigravity
- Cursor
- ChatGPT/custom instructions
- Universal `AGENTS.md`

Screenshot slots:

```text
[Screenshot: adapter folders]
[Screenshot: copying the selected adapter into a project]
```

## 5. Install For Codex

Show:

- Where the Codex skill folder is.
- Which folder to copy.
- How to invoke `$system-website-project-builder`.

## 6. Install For Claude Code

Show:

- Copy `CLAUDE.md` to the project root.
- Merge with existing project instructions.
- Run the first test prompt.

## 7. Install For Antigravity

Show:

- Copy `.antigravityrules` to the project root.
- Merge with existing rules instead of replacing them.
- Run the first test prompt.

## 8. Install For Cursor

Show:

- Copy `.cursor/rules/system-website-project-builder.mdc`.
- Confirm the rule is enabled.
- Run the first test prompt.

## 9. Install For ChatGPT

Show:

- Paste `MASTER-PROMPT.md` into the first chat or project instructions.
- Attach or paste the relevant kit instructions for longer work.

## 10. First Test Prompt

Include:

```text
Use Aivis Agent Skills - Brain Project Builder v1.4.
Inspect this project first.
Tell me the mode, primary kit, supporting kit rules, risk level, current phase, next phase, and whether you can proceed or need confirmation.
```

## 11. Database Confirmation Flow

Show:

- Existing/client-safe work follows the real database.
- Prototype Mode may propose database design.
- Proposed fields must be labeled `proposed`.
- Production/client schema needs confirmation before final SQL or migration work.

## 12. Style Confirmation Flow

Show:

- Small UI maintenance does not need a full design questionnaire.
- Major UI work asks whether to keep old design or redesign.
- Major UI work confirms theme, colors, typography, layout feel, references, and image use.

## 13. Deployment Flow

Show both paths:

- Legacy PHP/shared hosting: Laragon, cPanel, InfinityFree, phpMyAdmin, FTP/File Manager.
- Modern deployment: GitHub Pages, Vercel, Netlify, Docker, GitHub Actions/CI, env vars, cloud/VPS basics.

## 14. Final Verification

Explain:

- Simple tasks get focused verification.
- Full builds, deployments, releases, and final ZIP/package delivery get the full matrix.
- The AI must say what was not available.

## 15. Troubleshooting

Include:

- AI still pauses too much: remind it to use risk gates.
- AI invents facts: remind it to label proposals.
- AI gives a bloated matrix: ask for scope-aware verification.
- AI ignores modern deployment: ask it to detect deployment target first.
