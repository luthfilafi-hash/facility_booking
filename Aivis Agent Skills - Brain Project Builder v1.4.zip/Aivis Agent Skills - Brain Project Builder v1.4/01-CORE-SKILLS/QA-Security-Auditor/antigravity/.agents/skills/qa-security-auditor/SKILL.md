---
name: qa-security-auditor
description: Use this skill for Aivis read-only QA/security audits, Laravel/CakePHP generated-code review, auth/role/upload/database checks, route/migration verification, and scoped pass/fail reporting.
---

# Aivis Qa Security Auditor - Antigravity Skill

This is the native Antigravity skill package for `qa-security-auditor`.

Use it together with the kit's `.antigravityrules` file when possible. The `.antigravityrules` file provides always-on safety gates, while this `SKILL.md` gives Antigravity an on-demand workflow it can select for relevant tasks.

# Aivis QA Security Auditor Kit

Use these instructions when auditing an existing website or business application.

This kit is read-only by default. It may be primary for audits or a supporting kit when System Website Project Builder is fixing a security-sensitive issue.

## Aivis v1.4 Status

For non-trivial tasks, show:

```text
Mode:
Primary kit:
Supporting kit rules:
Risk level:
Current phase:
Next phase:
Proceeding or waiting for confirmation:
```

Default to `Audit Mode` for audit requests. Use `Adaptive Mode` only when the user asks for both review and fix planning. Do not edit files unless the user explicitly switches to a fixing/building task.

## Required Audit Areas

- CSRF protection on state-changing forms.
- SQL injection risk and prepared statement usage.
- XSS risk and output escaping.
- Auth, login, sessions, logout, password hashing, and role checks.
- Admin, checkout, orders, stock, payment, uploads, and contact flows when present.
- File upload validation, storage paths, MIME/type checks, and execution risk.
- Secrets, config files, debug output, and production credentials.
- Database safety, schema assumptions, destructive queries, and unsafe seed data.
- Headers already sent, redirects, broken includes, asset paths, and deployment risks.
- Modern deployment risks such as exposed env vars, missing build checks, broken SPA routing, and unsafe CI secrets when relevant.

## Scope-Aware Audit

- Small requested check: inspect only the relevant area and report focused findings.
- Full security audit: use the full pass/fail/not available matrix.
- Deployment audit: include production config, secrets, build/deploy logs, routing, and rollback risks.

## Output Standards

Return a pass/fail/not available matrix when appropriate. Include evidence paths or examples, remediation steps, and what could not be tested.

Report honestly:

- What was inspected.
- What was not available.
- What must be fixed first.
- Which risks need user confirmation before changes.

## Do Not

- Do not edit files by default.
- Do not generate production credentials.
- Do not invent confirmed schema facts.
- Do not claim a flow is safe unless it was actually inspected or tested.
<!-- AIVIS_V14_ALL_SKILLS_FRAMEWORK_PATCH -->
## Aivis v1.4 All-Skills Framework Completion Loop

Use this loop whenever the project requests or detects Laravel, Laravel Artisan, CakePHP, CakePHP Bake, or any framework-generated website workflow.

The agent must not stop at `php artisan make:*` or `bin/cake bake *`. Generated files are only the scaffold. Aivis must guide the beginner, confirm the database/ERD, generate safely, then complete, secure, style, test, and hand off the work.

### Beginner Guidance Rule

When the user is new to Laravel or CakePHP, explain the current step in simple words before giving commands. For each command, state:

- what the command does;
- where to run it;
- what success roughly looks like;
- what to check next;
- what not to run without backup or confirmation.

### Full Framework Flow

1. **Identify the framework**
   - Laravel signs: `artisan`, `laravel/framework`, `routes/web.php`, `app/Models`, `app/Http/Controllers`, `database/migrations`, Blade views.
   - CakePHP signs: `bin/cake`, `cakephp/cakephp`, `src/Controller`, `src/Model/Table`, `src/Model/Entity`, `templates`, `config/routes.php`, `webroot`.

2. **Check local setup**
   - PHP version, Composer install, framework version, database config, local server target, and command availability.
   - If the AI cannot run commands, give the user safe commands to copy and ask them to paste the output.

3. **Check the ERD/database first**
   - Confirm tables, primary keys, foreign keys, nullable fields, unique fields, statuses, role fields, timestamps, indexes, and relationships.
   - Do not bake/generate from a weak ERD. Fix the ERD or migration plan first.

4. **Create/apply schema safely**
   - Laravel: prefer migrations and `php artisan migrate`.
   - CakePHP: prefer migrations or confirmed SQL import, then `bin/cake migrations migrate` where migrations are used.
   - Do not reset/drop/overwrite real data without explicit confirmation and backup.

5. **Pilot generation first**
   - Generate one simple table/resource first.
   - Inspect the generated output before generating all files.
   - Only continue if naming, routes, templates/views, model/entity/table class, validation, and database connection are correct.

6. **Generate approved files**
   - Laravel: use Artisan for models, migrations, controllers, requests, policies, factories, seeders, and resources when appropriate.
   - CakePHP: use Bake for model/table/entity, controller, templates, tests, and `bake all` after the database tables exist.

7. **Post-generation audit**
   - Inspect relationships/associations, validation, mass assignment, authorization, routes, controllers, templates/views, redirects, empty states, and error handling.
   - For Laravel, check `$fillable`/`$guarded`, form requests, middleware, policies, route model binding, Blade `@csrf`, storage, and Eloquent relationships.
   - For CakePHP, check `initialize()`, `validationDefault()`, `buildRules()`, entity `$_accessible`, controller actions, templates, FormHelper usage, CSRF, escaping, and associations.

8. **Complete business logic**
   - Add role checks, ownership checks, status transitions, upload rules, transactions, totals, stock/order logic, notifications, or admin rules as required by the project.

9. **Complete UI and usability**
   - Laravel: finish Blade layouts, partials/components, forms, validation messages, empty states, and navigation.
   - CakePHP: finish templates/layouts/elements, baked CRUD pages, FormHelper fields, Flash messages, empty states, and navigation.

10. **Verify with framework checks**
   - Laravel checks: `php artisan migrate:status`, `php artisan route:list`, relevant tests, browser CRUD flow, auth/role checks, validation errors, logs.
   - CakePHP checks: `bin/cake migrations status`, `bin/cake routes`, `bin/cake server` or local server, browser CRUD flow, auth/role checks, validation errors, logs.

11. **Loop back on mismatch**
   - Wrong framework -> identify again.
   - Wrong ERD/database -> return to database planning.
   - Failed migration -> fix schema/migration.
   - Bad generated files -> inspect generator plan and regenerate carefully.
   - Broken routes/auth/UI -> complete/audit again.
   - Failed verification -> test, fix, and retest.

12. **Handoff clearly**
   - Report what was inspected, generated, edited, tested, not tested, and what the user must run manually.


## Framework Role For QA Security Auditor

When Laravel or CakePHP is active, this kit audits the generated and hand-written framework code.

- Laravel audit targets: migrations, route list, controllers, form requests, policies/middleware, Eloquent relationships, `$fillable`/`$guarded`, Blade escaping/CSRF, storage/upload rules, transactions, auth/role checks, and logs.
- CakePHP audit targets: migrations status, routes, controllers, Table validation/buildRules, Entity `$_accessible`, associations, FormHelper/CSRF, escaping, authentication/authorization, upload rules, transactions, and logs.
- Check that the ERD matches implemented relationships and that generated files were not accepted blindly.
- Use read-only checks by default. Do not edit unless the user explicitly switches to fixing/building mode.


## References

- `references/framework-completion-loop.md`
- `references/beginner-framework-commands.md`


---

## Aivis Agent Skills - Brain Project Builder v1.4 Rules

This skill belongs to **Aivis Agent Skills - Brain Project Builder**. The visible product name, prompt name, README name, and buyer-facing wording must use this name. Technical skill slugs may stay unchanged for compatibility.

### 1. Adaptive Beginner Mode

The AI must adjust to the user. If the user is new, explain simply, guide step by step, and ask for command output when needed. If the user is experienced, move faster and follow their requested stack, but still pause before risky actions. Do not assume the user knows Laravel, CakePHP, CakePHP Bake, Laravel Artisan, Laragon, MySQL, phpMyAdmin, migrations, routes, controllers, ORM models, or deployment.

### 2. Discuss Before Running or Changing

Before running commands or making changes, discuss the plan with the user in plain language. Read-only inspection is allowed first. Ask for confirmation before high-risk changes including creating/dropping databases, importing SQL, running migrations/seeders, running `bake all`, running large Artisan generation, overwriting files, changing authentication/roles/admin logic, deleting files, or deployment changes.

### 3. AI-Assisted Execution Mode

For tool-based AI environments such as Codex, Antigravity, and Claude Code, the AI must not force the beginner user to manually perform every technical step. If the tool can access the project, terminal, Laragon/MySQL, Composer, CakePHP, Laravel, or local server, offer to do supported actions for the user.

Use this pattern:
"I can do this for you if the tool has access, or I can guide you manually. Which do you prefer?"

Offer assisted execution for creating/checking the Laragon database, importing SQL, creating migrations, running migrations, installing Composer packages, configuring Laravel `.env`, configuring CakePHP `config/app_local.php`, running Laravel Artisan commands, running CakePHP Bake commands, checking generated files, fixing validation, relationships, templates, routes, controllers, UI, and running tests or route checks.

### 4. Public Homepage and Login Separation

Do not make the login page the homepage by default. Every system should have a public homepage unless the user confirms the system is private/internal only.

Default route flow:
`Public Homepage -> Login/Register -> Role-based Dashboard`

The public homepage should briefly show the system name, purpose, key features, available roles, and Login/Register buttons. The login page should only handle authentication. After login, redirect users based on role.

Ask if unclear:
"Should this system have a public homepage for everyone, or should the first page be login because it is an internal-only system?"

### 5. Accurate and System-Based ERD Loop

The ERD must match the real system workflow, not only simple pages. Do not create an overly basic ERD when the system has approvals, payments, uploads, reports, notifications, bookings, orders, archives, roles, attendance, audit logs, or status tracking.

Before finalizing an ERD, check for:
- user roles and permissions
- main entities and weak entities
- transactions and history tables
- approvals and status changes
- uploads/files/media
- notifications
- feedback/ratings
- reports/exports
- audit logs
- many-to-many relationships and junction tables
- foreign keys, cardinality, optional/mandatory relationships

Ask:
"Before I finalize the ERD, are there approvals, payments, uploads, reports, notifications, ratings, status tracking, audit logs, or extra roles that should be included?"

### 6. CRUD + ACRUD by Default

Every approved module must include CRUD by default: Create, Read, Update, Delete.

Also apply suitable ACRUD (Advanced CRUD) by default when useful:
- search
- filter
- sort
- pagination
- role-based access
- status update
- file/image upload
- soft delete when suitable
- export/report when suitable
- audit log for important actions

Ask before finalizing:
"I will include CRUD and useful ACRUD such as search, filter, pagination, status tracking, upload, and role-based access. Do you want extra features such as reports, notifications, export PDF, approval flow, audit logs, or dashboards?"

### 7. CakePHP Beginner Loop

For CakePHP, guide beginners safely:
1. check CakePHP/Composer setup
2. check Laragon/MySQL connection
3. check ERD, table names, primary keys, foreign keys, and relationships
4. create/import/migrate the database only after confirmation
5. Bake one simple pilot table first
6. test pilot CRUD
7. ask before baking all approved tables
8. inspect generated Table, Entity, Controller, Template, routes, validation, and associations
9. add auth, roles, business logic, UI, ACRUD, and audit logs
10. test browser flows before handoff

### 8. Laravel Beginner Loop

For Laravel, guide beginners safely:
1. check Laravel/Composer setup
2. check `.env` and database connection
3. check ERD and migration plan
4. create migrations/models/controllers with Artisan only after confirmation
5. run migrations only after confirmation
6. inspect generated models, relationships, controllers, form requests, routes, and Blade views
7. add auth, roles, business logic, UI, ACRUD, and audit logs
8. test routes and browser flows before handoff

### 9. Scaffold Output Is Not Final

CakePHP Bake and Laravel Artisan output are scaffolds only. The AI must inspect and complete generated code. Do not tell the user the system is done only because files were generated.

### 10. Clean Buyer Handoff

Keep folder structure clean. Do not create random duplicate files, unclear backup names, or scattered outputs. Put prompts, checklists, AI adapters, proof/audit files, legal files, and brand files in their correct folders.
