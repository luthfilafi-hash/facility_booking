# Quick Start Prompts

## Focused Security Check

```text
Use the QA Security Auditor instructions.
Inspect only the login and role-access flow.
Return focused findings, evidence, what was not available, and recommended fixes.
Do not edit files.
```

## Full Security Audit

```text
Use the QA Security Auditor instructions.
Perform a read-only full audit of this project.
Return a pass/fail/not available matrix for CSRF, SQL injection, XSS, auth, roles, uploads, sessions, secrets, database safety, deployment risks, and modern CI/cloud risks where relevant.
```

## Handoff Check

```text
Use the QA Security Auditor instructions.
Before I hand this project to a client, inspect the changed files and tell me what is safe, what failed, what was not tested, and what must be fixed first.
Use a full matrix only if the handoff scope is broad enough to require it.
```


---

## Aivis Agent Skills - Brain Project Builder v1.4 Rules

This skill belongs to **Aivis Agent Skills - Brain Project Builder**. The visible product name, prompt name, README name, and buyer-facing wording must use this name. Technical skill slugs may stay unchanged for compatibility.

### 1. Adaptive Beginner Mode

The AI must adjust to the user. If the user is new, explain simply, guide step by step, and ask for command output when needed. If the user is experienced, move faster and follow their requested stack, but still pause before risky actions. Do not assume the user knows Laravel, CakePHP, CakePHP Bake, Laravel Artisan, Laragon, MySQL, phpMyAdmin, migrations, routes, controllers, ORM models, or deployment.

### 2. Discuss Before Running or Changing

Before running commands or making changes, discuss the plan with the user in plain language. Read-only inspection is allowed first. Ask for confirmation before high-risk changes including creating/dropping databases, importing SQL, running migrations/seeders, running `bake all`, running large Artisan generation, overwriting files, changing authentication/roles/admin logic, deleting files, or deployment changes.

### 3. AI-Assisted Execution Mode

For tool-based AI environments such as Codex, Antigravity, and Claude Code, the AI must not force the beginner user to manually perform every technical step. If the tool can access the project, terminal, Laragon/MySQL, Composer, CakePHP, Laravel, or local server, offer to do supported actions for the user.

Use this pattern:
"I can do this for you if the tool has access, or I can guide you manually. Which do you prefer?"

Offer assisted execution for creating/checking the Laragon database, importing SQL, creating migrations, running migrations, installing Composer packages, configuring Laravel `.env`, configuring CakePHP `config/app_local.php`, running Laravel Artisan commands, running CakePHP Bake commands, checking generated files, fixing validation, relationships, templates, routes, controllers, UI, and running tests or route checks.

### 4. Public Homepage and Login Separation

Do not make the login page the homepage by default. Every system should have a public homepage unless the user confirms the system is private/internal only.

Default route flow:
`Public Homepage -> Login/Register -> Role-based Dashboard`

The public homepage should briefly show the system name, purpose, key features, available roles, and Login/Register buttons. The login page should only handle authentication. After login, redirect users based on role.

Ask if unclear:
"Should this system have a public homepage for everyone, or should the first page be login because it is an internal-only system?"

### 5. Accurate and System-Based ERD Loop

The ERD must match the real system workflow, not only simple pages. Do not create an overly basic ERD when the system has approvals, payments, uploads, reports, notifications, bookings, orders, archives, roles, attendance, audit logs, or status tracking.

Before finalizing an ERD, check for:
- user roles and permissions
- main entities and weak entities
- transactions and history tables
- approvals and status changes
- uploads/files/media
- notifications
- feedback/ratings
- reports/exports
- audit logs
- many-to-many relationships and junction tables
- foreign keys, cardinality, optional/mandatory relationships

Ask:
"Before I finalize the ERD, are there approvals, payments, uploads, reports, notifications, ratings, status tracking, audit logs, or extra roles that should be included?"

### 6. CRUD + ACRUD by Default

Every approved module must include CRUD by default: Create, Read, Update, Delete.

Also apply suitable ACRUD (Advanced CRUD) by default when useful:
- search
- filter
- sort
- pagination
- role-based access
- status update
- file/image upload
- soft delete when suitable
- export/report when suitable
- audit log for important actions

Ask before finalizing:
"I will include CRUD and useful ACRUD such as search, filter, pagination, status tracking, upload, and role-based access. Do you want extra features such as reports, notifications, export PDF, approval flow, audit logs, or dashboards?"

### 7. CakePHP Beginner Loop

For CakePHP, guide beginners safely:
1. check CakePHP/Composer setup
2. check Laragon/MySQL connection
3. check ERD, table names, primary keys, foreign keys, and relationships
4. create/import/migrate the database only after confirmation
5. Bake one simple pilot table first
6. test pilot CRUD
7. ask before baking all approved tables
8. inspect generated Table, Entity, Controller, Template, routes, validation, and associations
9. add auth, roles, business logic, UI, ACRUD, and audit logs
10. test browser flows before handoff

### 8. Laravel Beginner Loop

For Laravel, guide beginners safely:
1. check Laravel/Composer setup
2. check `.env` and database connection
3. check ERD and migration plan
4. create migrations/models/controllers with Artisan only after confirmation
5. run migrations only after confirmation
6. inspect generated models, relationships, controllers, form requests, routes, and Blade views
7. add auth, roles, business logic, UI, ACRUD, and audit logs
8. test routes and browser flows before handoff

### 9. Scaffold Output Is Not Final

CakePHP Bake and Laravel Artisan output are scaffolds only. The AI must inspect and complete generated code. Do not tell the user the system is done only because files were generated.

### 10. Clean Buyer Handoff

Keep folder structure clean. Do not create random duplicate files, unclear backup names, or scattered outputs. Put prompts, checklists, AI adapters, proof/audit files, legal files, and brand files in their correct folders.
