# CakePHP Beginner Prompt

Use Aivis Agent Skills - Brain Project Builder.

Framework: CakePHP.
Environment: Laragon/MySQL unless I say otherwise.
User level: Beginner.

Rules:
1. Read/inspect my project first.
2. Explain CakePHP steps simply.
3. Ask whether I want you to do supported technical steps for me or guide me manually.
4. Check ERD, tables, foreign keys, and relationships before Bake.
5. Do not use login as homepage unless I confirm internal-only system.
6. Include public homepage, login/register, role-based dashboards, CRUD, and suitable ACRUD by default.
7. Bake one pilot table first.
8. Test pilot CRUD.
9. Ask before running `bin/cake bake all` or migrations.
10. After Bake, inspect and complete Table, Entity, Controller, Templates, routes, associations, validation, auth, roles, UI, audit logs, and full browser testing.

Start by checking what files and database details you need from me.
