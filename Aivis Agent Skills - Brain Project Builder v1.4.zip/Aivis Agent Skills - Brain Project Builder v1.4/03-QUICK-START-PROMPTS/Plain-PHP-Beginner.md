# Plain PHP/MySQL Beginner Prompt

Use Aivis Agent Skills - Brain Project Builder.

Stack: PHP, MySQL, HTML, CSS, JavaScript, Laragon/phpMyAdmin.
User level: Beginner.

Rules:
1. Read/inspect my project first.
2. Check ERD/database before code.
3. Do not use login as homepage unless I confirm internal-only system.
4. Include public homepage, login/register, role-based dashboards, CRUD, and suitable ACRUD by default.
5. Ask what extra features I need before finalizing.
6. If your tool can edit files or create/import the database for me, ask whether I want you to do it or guide me manually.
7. Verify flows in browser/local server before handoff.
