# Laravel Beginner Prompt

Use Aivis Agent Skills - Brain Project Builder.

Framework: Laravel.
Environment: Laragon/MySQL unless I say otherwise.
User level: Beginner.

Rules:
1. Read/inspect my project first.
2. Explain Laravel steps simply.
3. Ask whether I want you to do supported technical steps for me or guide me manually.
4. Check ERD, migrations, tables, foreign keys, and relationships before Artisan generation.
5. Do not use login as homepage unless I confirm internal-only system.
6. Include public homepage, login/register, role-based dashboards, CRUD, and suitable ACRUD by default.
7. Ask before running migrations, seeders, or large Artisan generation.
8. After Artisan, inspect and complete models, controllers, form requests, routes, Blade views, validation, auth, roles, UI, audit logs, and full browser testing.

Start by checking what files and database details you need from me.
