# Compatibility Matrix

Use `MASTER-PROMPT.md` as the primary universal instruction for buyers who want one complete prompt. Use this matrix only when installing an optional adapter for a specific AI environment.

| AI Tool | Adapter | Install Notes |
| --- | --- | --- |
| Any supported AI | `MASTER-PROMPT.md` | Paste this first when you want one complete prompt and automatic kit/framework selection. |
| Codex | `codex/<skill-name>/SKILL.md` | Copy the skill folder into the Codex skills directory. |
| Claude Code | `claude/CLAUDE.md` | Copy or merge into the project `CLAUDE.md`. |
| Cursor | `cursor/.cursor/rules/<kit-name>.mdc` | Copy into `.cursor/rules/`. Keep frontmatter. |
| Antigravity | `antigravity/.antigravityrules` | Copy or merge into `.antigravityrules`. |
| ChatGPT | `MASTER-PROMPT.md` or `chatgpt/PROJECT-INSTRUCTIONS.md` | Prefer `MASTER-PROMPT.md` for complete bundle behavior. Use the adapter for a kit-specific ChatGPT Project. |
| Generic AI | `AGENTS.md` | Paste or attach as project instructions. |

## v1.4 Usage Pattern

- The AI should choose one primary kit and optional supporting kit rules.
- The AI should report mode and risk level for non-trivial work.
- Low-risk work should not be blocked by production-level confirmation.
- High-risk work must still pause for confirmation.
- Laravel/CakePHP projects must use the Stable Loop before scaffold generation.
- Artisan/Bake output must be audited and completed before the AI claims done.

## Kit Selection

- Use System Website Project Builder for full-stack website work, including Laravel Artisan and CakePHP Bake projects.
- Use Architecture Designer for planning-only database, ERD, file structure, and team task splitting.
- Use UI Component Builder for frontend-only UI and visual polish.
- Use QA Security Auditor for read-only QA/security audits.
- Use Deployment Admin for shared hosting, modern deployment, Git/cloud/static/container workflows, and release checks.

## Framework Compatibility

| Framework / Tool | Aivis Handling |
| --- | --- |
| Plain PHP/MySQL | Uses original Aivis fallback stack and database-first rules. |
| Laravel | Uses Laravel conventions for migrations, Eloquent, controllers, routes, Blade, middleware, validation, auth, CSRF, and verification. |
| Laravel Artisan | Uses Artisan for scaffold generation, then audits and completes generated files. |
| CakePHP | Uses CakePHP conventions for table/entity/controller/templates, ORM associations, routes, validation, auth, CSRF, escaping, and verification. |
| CakePHP Bake | Uses Bake after schema confirmation, then audits and completes generated files. |


## Framework Recheck Notes

- Antigravity: compatible through both `.antigravityrules` and native Skill folder `antigravity/.agents/skills/system-website-project-builder/`.
- Laravel: compatible through Artisan workflow after readiness checks and database/migration gates.
- CakePHP: compatible through Bake workflow after Bake/Migrations availability checks and database/migration gates.
