# Quick Start Bundle Prompts

## Universal v1.4 Test

```text
Use the Aivis Agent Skills - Brain Project Builder v1.4 master prompt.
Inspect this project first.
Do not code yet unless the task is low risk.
Tell me the mode, primary kit, supporting kit rules, risk level, current phase, next phase, and whether you can proceed or need confirmation.
```

## Laravel Test

```text
Use Aivis Agent Skills - Brain Project Builder v1.4.
This project uses Laravel.
Run the Stable Loop first.
Use Laravel conventions and Artisan commands.
Do not generate files until the database/migration shape and risk gates are clear.
```

## CakePHP Test

```text
Use Aivis Agent Skills - Brain Project Builder v1.4.
This project uses CakePHP.
Run the Stable Loop first.
Use CakePHP conventions and Bake.
Do not run `bin/cake bake all` until the database/migration shape and risk gates are clear.
```

## Prototype Mode

```text
Use Aivis Agent Skills - Brain Project Builder v1.4 in Prototype Mode.
Create a proposed MVP plan for a [project type] website.
Label proposed pages, tables, fields, roles, statuses, and workflows clearly.
If Laravel or CakePHP is chosen, map the proposal into migrations, models/table classes, controllers, routes, and views/templates.
```

## Client-Safe Mode

```text
Use Aivis Agent Skills - Brain Project Builder v1.4 in Client-Safe Mode.
This is for a real client or graded project.
Inspect first, then pause before final database schema, auth/roles, admin permissions, payments, orders, uploads, secrets, destructive database changes, or production deployment.
```

## Maintenance Mode

```text
Use Aivis Agent Skills - Brain Project Builder v1.4 in Maintenance Mode.
Inspect only the affected files first, make the smallest safe fix, and report only relevant checks.
```
