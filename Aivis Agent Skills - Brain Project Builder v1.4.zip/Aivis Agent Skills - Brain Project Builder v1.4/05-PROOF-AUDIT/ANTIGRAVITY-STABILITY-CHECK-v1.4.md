# Antigravity Stability Check - v1.4

Antigravity structure included:

- `.antigravityrules`
- `project-root/.agents/skills/architecture-designer/SKILL.md`
- `project-root/.agents/skills/system-website-project-builder/SKILL.md`
- `project-root/.agents/skills/ui-component-builder/SKILL.md`
- `project-root/.agents/skills/qa-security-auditor/SKILL.md`
- `project-root/.agents/skills/deployment-admin/SKILL.md`
- `references/` folders where needed

Antigravity-specific behavior:

- offer to perform supported technical actions when workspace/terminal/database access exists
- ask before risky commands
- guide beginners step by step
- check ERD/database before CakePHP Bake or Laravel Artisan
- do not treat generated scaffold files as finished
