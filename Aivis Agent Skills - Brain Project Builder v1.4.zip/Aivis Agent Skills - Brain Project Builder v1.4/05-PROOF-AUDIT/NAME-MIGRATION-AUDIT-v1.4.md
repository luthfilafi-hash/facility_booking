# Name Migration Audit - v1.4

New official name:

`Aivis Agent Skills - Brain Project Builder`

Visible names, README files, prompts, proof files, and instruction files were updated to use the new product name.

Technical skill slugs remain stable for compatibility:

- architecture-designer
- system-website-project-builder
- ui-component-builder
- qa-security-auditor
- deployment-admin

Reason: Antigravity and Codex may rely on these skill folder names.
