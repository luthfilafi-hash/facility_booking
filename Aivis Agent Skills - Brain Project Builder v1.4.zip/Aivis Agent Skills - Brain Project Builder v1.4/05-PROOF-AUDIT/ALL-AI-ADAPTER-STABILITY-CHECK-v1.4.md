# All AI Adapter Stability Check - v1.4

Checked adapters:

- ChatGPT Project instructions
- Claude Code CLAUDE.md files
- Codex SKILL.md folders
- Cursor .mdc rules
- Antigravity .antigravityrules and native skills
- Generic AGENTS.md files

Required rules added or verified:

- Beginner adaptive guidance
- AI-assisted execution mode
- Discuss before running commands
- Homepage/login separation
- ERD accuracy and complexity
- CRUD + ACRUD default
- Ask for extra features
- CakePHP beginner loop
- Laravel beginner loop
- Scaffold output is not final
- Clean buyer handoff
