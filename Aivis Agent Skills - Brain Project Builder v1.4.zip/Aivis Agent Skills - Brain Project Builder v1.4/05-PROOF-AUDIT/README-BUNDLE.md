# Aivis Agent Skills - Brain Project Builder v1.4

Aivis Agent Skills - Brain Project Builder v1.4 is a buyer-ready multi-AI instruction package for website planning, building, UI work, security audits, deployment, and framework-aware project generation.

The bundle is built for client project work, fast prototyping, and small maintenance tasks. Version 1.4 adds framework-fit support so the same Aivis workflow can be used with plain PHP, Laravel, Laravel Artisan, CakePHP, and CakePHP Bake.

## Main Buyer Instruction

Use `MASTER-PROMPT.md` as the single canonical long prompt for most buyers. It lets the AI choose the correct kit, mode, risk level, supporting rules, and framework behavior from one complete instruction block.

The per-tool adapter files inside each kit are optional install files for AI tools that support project rules or skill folders. They are not separate prompts that must all be pasted together.

## Included Kits

- `system-website-project-builder-kit.zip`: Adaptive full-stack website planning, building, conversion, maintenance, security, verification, prototyping, deployment, Laravel Artisan, and CakePHP Bake workflows.
- `architecture-designer-kit.zip`: Planning-first database, ERD, entity/attribute, file-structure, feature-boundary, prototype schema, and team-splitting guidance.
- `ui-component-builder-kit.zip`: Frontend-only theme, color, typography, CSS variable, HTML/CSS/JS component, responsive UI, accessibility, visual matching, and scoped UI maintenance guidance.
- `qa-security-auditor-kit.zip`: Read-only security and QA auditing with focused or full pass/fail reporting.
- `deployment-admin-kit.zip`: Deployment guidance for Laragon/shared hosting/cPanel/phpMyAdmin plus GitHub Pages, Vercel, Netlify, Docker, Git/CI, environment variables, and cloud/VPS basics.

## v1.4 Concepts

- `Adaptive Mode`: default balanced workflow.
- `Client-Safe Mode`: strict confirmation for real client, production, graded, or business-critical systems.
- `Prototype Mode`: fast MVP workflow where the AI may propose schemas and flows if labeled `proposed`.
- `Maintenance Mode`: scoped fixes without full workflow bloat.
- `Audit Mode`: read-only review.
- `Deployment Mode`: hosting, release, production config, CI/CD, and migration work.
- `Stable Loop`: detects Laravel/CakePHP, maps Aivis phases to framework conventions, uses Artisan/Bake correctly, audits generated files, completes missing logic, verifies, and loops back on mismatch.

Risk gates remain:

- Low risk: inspect and proceed.
- Medium risk: proceed with labeled assumptions or ask compact confirmation.
- High risk: pause and confirm.

## Supported AI Tools

- Primary universal prompt: `MASTER-PROMPT.md`.
- Codex skill format.
- Claude Code `CLAUDE.md`.
- Cursor `.mdc` rules.
- Antigravity `.antigravityrules`.
- ChatGPT/custom project instructions.
- Generic AI via `AGENTS.md`.

## Buyer Setup Flow

1. Open `START-HERE.pdf`.
2. Use `MASTER-PROMPT.md` first if you want one complete prompt that covers the whole bundle.
3. Optional: install one adapter for your AI tool when the tool supports project rules or skill folders.
4. Run one quick-start prompt.
5. For Laravel/CakePHP projects, say the framework and ask the AI to run the Stable Loop first.
6. Check that the AI reports mode, primary kit, supporting rules, risk level, current phase, next phase, and whether it can proceed.

## Client-Use Terms

This bundle is for the buyer's own/client project work only. It may not be resold, redistributed, repackaged, uploaded to marketplaces, sublicensed, or claimed as the buyer's own kit.
