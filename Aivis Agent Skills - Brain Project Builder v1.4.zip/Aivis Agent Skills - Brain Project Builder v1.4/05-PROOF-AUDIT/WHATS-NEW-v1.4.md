# What's New - Aivis Agent Skills - Brain Project Builder v1.4

Release date: 2026-06-24

## Main Update

Aivis now has framework-fit support for Laravel, Laravel Artisan, CakePHP, and CakePHP Bake.

This means the same Aivis workflow can still be used, but the AI will not force plain PHP structure when a framework is requested or detected.

## Added

- Stable Loop.
- Laravel Adapter Rules.
- CakePHP Adapter Rules.
- Laravel Artisan quick-start prompt.
- CakePHP Bake quick-start prompt.
- Post-scaffold audit rule.
- Framework-specific final reporting format.
- `03-Proof/FRAMEWORK-FIT-LOOP.md`.
- `03-Proof/WHATS-NEW-v1.4.md`.
- `03-Proof/UPDATE-AUDIT-LOG-v1.4.md`.
- System kit references and examples for Laravel/CakePHP.

## Improved

- Master prompt now detects framework choices earlier.
- Database-first workflow now maps to migrations/schema in Laravel and CakePHP.
- Verification now includes generator output checks, routes, migrations, controllers, templates/views, auth/security, and manual framework checks.
- Buyer setup flow now explains how to use Laravel or CakePHP with Aivis.

## Important Rule

Laravel Artisan and CakePHP Bake are scaffold generators. Aivis v1.4 tells the AI to inspect and complete generated files before saying the feature is done.


## Antigravity QA Patch

The rechecked build adds native Antigravity Skill packaging, Artisan/Bake readiness checks, CakePHP Bake/Migrations fallback handling, route/migration verification commands, and safer terminal command gates for Antigravity workflows.


## CakePHP Beginner Guidance Patch

- Added a beginner-safe CakePHP workflow.
- Added ERD/database readiness checks before Bake.
- Added pilot Bake before baking all tables.
- Added explicit post-Bake completion steps: audit generated files, fix associations/validation, add auth/roles/business logic, improve UI/templates, verify routes, test CRUD, and run final security checks.
- Added Antigravity-specific step-by-step guidance for users who do not know CakePHP commands.

<!-- AIVIS_V14_ALL_SKILLS_WHATSNEW_PATCH -->
## Patch: All-Skills Framework Completion

- Laravel/CakePHP framework roles added to Architecture Designer, UI Component Builder, QA Security Auditor, and Deployment Admin.
- Antigravity native `SKILL.md` packages added for every kit.
- Beginner-safe CakePHP/Laravel command guidance added across adapters.
- Full flow now covers ERD -> generator -> post-generation audit -> UI -> QA/security -> deployment.

---

# What's New - Aivis Agent Skills - Brain Project Builder v1.4

## New name

The package is now named **Aivis Agent Skills - Brain Project Builder**.

## Cleaner buyer folder layout

The bundle now starts with `00-START-HERE` and separates core skills, AI app installs, quick-start prompts, templates/checklists, proof/audit, legal, and brand files.

## Homepage/login rule

Systems should have a public homepage by default. Login is not the homepage unless the user confirms the system is private/internal only.

## More accurate ERD rules

The AI must build ERDs based on the full system workflow, including roles, approvals, uploads, notifications, reports, audit logs, and junction tables when needed.

## CRUD + ACRUD by default

Every approved module should include CRUD and suitable Advanced CRUD such as search, filter, pagination, status updates, uploads, reports, role-based access, and audit logs when suitable.

## AI-assisted execution mode

Codex, Antigravity, and Claude Code should offer to perform supported technical tasks for the user instead of forcing manual commands.

## Framework stability

Laravel Artisan and CakePHP Bake are supported with beginner-friendly loops, readiness checks, pilot generation, post-generation audits, and safety gates.
