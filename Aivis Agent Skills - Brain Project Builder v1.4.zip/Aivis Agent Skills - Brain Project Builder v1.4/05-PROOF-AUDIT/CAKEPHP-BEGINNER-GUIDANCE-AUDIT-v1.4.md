# CakePHP Beginner Guidance Audit - Aivis v1.4 Patch

Date: 2026-06-24
Patch label: v1.4 CakePHP Beginner Guidance

## Gap Found

The previous v1.4 patch correctly supported CakePHP and Bake, but it still assumed the user knew the CakePHP workflow. New users may not know what to do before and after `bin/cake bake all`.

## Fix Added

Added a beginner-safe CakePHP workflow that teaches the user:

1. what CakePHP, Composer, `bin/cake`, migrations, Bake, Table classes, Entities, Controllers, and Templates mean;
2. how to check the environment and CakePHP tools;
3. how to verify ERD/database readiness before Bake;
4. how to use migrations or imported SQL;
5. why one pilot Bake should run before baking every table;
6. what to do after `bake all`;
7. how to audit generated files;
8. how to complete auth, roles, business logic, UI, security, and CRUD verification.

## Files Updated

- `03-Proof/CAKEPHP-BEGINNER-GUIDED-WORKFLOW.md`
- `03-Proof/CAKEPHP-BEGINNER-GUIDANCE-AUDIT-v1.4.md`
- `MASTER-PROMPT.md`
- `01-Kits/system-website-project-builder-kit.zip`
- `05-Antigravity/project-root/.agents/skills/system-website-project-builder/SKILL.md`
- `05-Antigravity/project-root/.agents/skills/system-website-project-builder/references/cakephp-beginner-guided-workflow.md`
- Antigravity install/readme notes

## Final Rule

Bake output is not final. Aivis must continue through post-Bake audit, business logic, security, UI, route checks, and browser/manual CRUD testing before declaring the system ready.
