# Aivis Agent Skills - Brain Project Builder Version

Current version: `1.4`

## Release Label

```text
Aivis Agent Skills - Brain Project Builder v1.4
```

## Release Summary

This release keeps the adaptive workflow and adds framework-fit support for Laravel, Laravel Artisan, CakePHP, and CakePHP Bake.

Version 1.4 is designed so buyers can still use one master prompt, while the AI adapts to plain PHP, Laravel, CakePHP, or discovered web stacks without abandoning the Aivis database-first, risk-gated, UI-safe, security-aware workflow.

Included kits:

- Aivis Agent Skills - Brain Project Builder v1.4.
- Architecture Designer Kit v1.4.
- UI Component Builder Kit v1.4.
- QA Security Auditor Kit v1.4.
- Deployment Admin Kit v1.4.


## Recheck Patch

`v1.4 - Antigravity QA Patch` adds native Antigravity Skill packaging, stronger Artisan/Bake readiness checks, CakePHP plugin fallback handling, route/migration verification commands, and safer Antigravity command gates.


Patch label: v1.4 CakePHP Beginner Guidance Patch
Purpose: make CakePHP/Bake usable for beginners and safer inside Antigravity.

<!-- AIVIS_V14_ALL_SKILLS_ROOT_VERSION_PATCH -->
## v1.4 All-Skills Framework Completion Patch

Patch label: `v1.4 All-Skills Framework Completion Patch`.

This patch extends Laravel/CakePHP/Artisan/Bake guidance across all kits and all AI adapters, with special Antigravity native skill packaging for every kit.
