# Audit Log Template

Use audit logs for important actions.

Suggested table:

```sql
CREATE TABLE audit_logs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NULL,
  action VARCHAR(100) NOT NULL,
  table_name VARCHAR(100) NULL,
  record_id INT NULL,
  old_value JSON NULL,
  new_value JSON NULL,
  ip_address VARCHAR(45) NULL,
  user_agent TEXT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

Track actions such as:

- login/logout if required
- create/update/delete important records
- role changes
- approval/rejection
- payment/status changes
- file upload/delete
- deployment/admin configuration changes
