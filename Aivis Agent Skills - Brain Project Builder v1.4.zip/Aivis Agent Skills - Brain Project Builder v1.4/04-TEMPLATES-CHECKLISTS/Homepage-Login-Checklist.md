# Homepage and Login Checklist

Default rule: do not make login the homepage unless the user confirms the system is private/internal only.

## Public homepage should include

- System name
- Short explanation of the system
- Key features
- Available roles
- Login button
- Register button if registration is allowed
- Optional About/Contact section

## Login page should include

- Login form
- Validation messages
- Register link if registration is allowed
- Forgot password if required

## After login

- Redirect by role
- Protect dashboards with auth middleware/session check
- Prevent logged-in users from seeing login again unnecessarily
