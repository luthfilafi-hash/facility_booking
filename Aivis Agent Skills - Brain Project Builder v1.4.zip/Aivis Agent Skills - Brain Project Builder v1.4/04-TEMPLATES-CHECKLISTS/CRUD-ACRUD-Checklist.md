# CRUD and ACRUD Checklist

## CRUD by default

Every approved module should support:

- Create
- Read
- Update
- Delete

## ACRUD when useful

Add suitable Advanced CRUD features:

- Search
- Filter
- Sort
- Pagination
- Status updates
- Role-based access
- File/image uploads
- Soft delete
- Reports/export
- Audit logs

Ask before finalizing:

"I will include CRUD and useful ACRUD such as search, filter, pagination, status tracking, upload, and role-based access. Do you want extra features such as reports, notifications, export PDF, approval flow, audit logs, or dashboards?"
