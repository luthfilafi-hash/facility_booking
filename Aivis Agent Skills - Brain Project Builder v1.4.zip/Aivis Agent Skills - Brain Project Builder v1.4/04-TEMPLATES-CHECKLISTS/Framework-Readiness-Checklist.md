# Framework Readiness Checklist

## CakePHP

- Composer installed
- CakePHP project exists
- `bin/cake` or `bin\cake` works
- `cakephp/bake` installed for Bake
- `cakephp/migrations` installed if using migrations
- database configured in `config/app_local.php`
- ERD/tables checked before Bake
- pilot Bake tested before baking all tables

## Laravel

- Composer installed
- Laravel project exists
- `php artisan` works
- `.env` configured
- database connection works
- ERD/migrations checked before Artisan generation
- migrations run only after confirmation
- routes/controllers/models/views checked after generation
