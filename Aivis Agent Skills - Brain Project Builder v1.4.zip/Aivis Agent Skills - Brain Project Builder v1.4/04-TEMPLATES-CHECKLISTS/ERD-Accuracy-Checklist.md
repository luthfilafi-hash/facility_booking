# ERD Accuracy and Complexity Checklist

The ERD must reflect the real system workflow.

Check for:

- Users and roles
- Permissions/access control
- Main modules/entities
- Weak entities
- Junction tables for many-to-many relationships
- Status/approval tables
- Transaction/order/booking records
- Upload/file/media tables
- Notifications
- Feedback/ratings
- Reports/exports
- Audit logs
- Soft delete/archive needs
- Foreign keys
- Cardinality
- Optional/mandatory relationships

Ask before finalizing:

"Are there approvals, payments, uploads, reports, notifications, ratings, status tracking, audit logs, or extra roles that should be included?"
