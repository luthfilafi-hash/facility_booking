# Quick Install Guide - Aivis Agent Skills - Brain Project Builder v1.4

## Choose your AI app

- ChatGPT: use `02-INSTALL-BY-AI-APP/ChatGPT/`.
- Claude Code: use `02-INSTALL-BY-AI-APP/Claude-Code/`.
- Codex: use `02-INSTALL-BY-AI-APP/Codex/skills/`.
- Cursor: copy rules from `02-INSTALL-BY-AI-APP/Cursor/.cursor/rules/`.
- Antigravity: copy from `02-INSTALL-BY-AI-APP/Antigravity/project-root/` into your project root and use `.antigravityrules`.
- Generic agents: use `02-INSTALL-BY-AI-APP/Generic-Agents/`.

## Beginner mode

Tell the AI:

"Use Aivis Agent Skills - Brain Project Builder. I am a beginner. Read my project first, guide me step by step, ask before risky changes, and offer to do technical steps for me when your tool can do them."

## Framework mode

For CakePHP:

"Use Aivis Agent Skills - Brain Project Builder. Framework: CakePHP. Check ERD and database first, then guide setup, migrate/import SQL, Bake one pilot table, test it, then Bake approved tables and complete validation, relationships, auth, roles, UI, CRUD, ACRUD, and audit logs."

For Laravel:

"Use Aivis Agent Skills - Brain Project Builder. Framework: Laravel. Check ERD and database first, then guide setup, create migrations, run Artisan generation, inspect generated files, complete validation, relationships, auth, roles, UI, CRUD, ACRUD, and audit logs."
